from flask import Flask, jsonify, request
from cerebras.cloud.sdk import Cerebras 
import xgboost as xgb
import pandas as pd
import pymysql
import os

app = Flask(__name__)
application = app

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
models_cache = {}

@app.route('/predict/<symbol>', methods=['GET'])
def predict(symbol):
    try:
        filename = f"{symbol.lower()}_xgboost_model.json"
        filepath = os.path.join(BASE_DIR, filename)

        if not os.path.exists(filepath):
            return jsonify({'status': 'error', 'msg': f'Aucun modele entraine pour {symbol}'})

        current_mtime = os.path.getmtime(filepath)
        if symbol not in models_cache or current_mtime > models_cache[symbol]['mtime']:
            print(f"Chargement du nouveau modele pour {symbol} en RAM...")
            new_model = xgb.XGBRegressor()
            new_model.load_model(filepath)
            models_cache[symbol] = {'model': new_model, 'mtime': current_mtime}

        model = models_cache[symbol]['model']

        DB_HOST = 'mysql-othman.alwaysdata.net'
        DB_USER = 'othman'
        DB_PASS = 'Kf6.nLi,B8#$d3Z'
        DB_NAME = 'othman_titan'
        conn = pymysql.connect(host=DB_HOST, user=DB_USER, password=DB_PASS, database=DB_NAME)

        # ====================================================================
        # ⏱️ LA MACHINE À REMONTER LE TEMPS (Pour le Backtest)
        # ====================================================================
        target_date = request.args.get('date')

        # 🌟 REQUÊTES MACRO (VIX, DXY, US10Y)
        if target_date:
            date_filter = f"AND DATE(created_at) <= '{target_date}'"
        else:
            date_filter = ""

        vix_query = f"SELECT price as vix_price, DATE(created_at) as date FROM market_history WHERE symbol = 'VIX' {date_filter} ORDER BY date DESC LIMIT 60"
        dxy_query = f"SELECT price as dxy_price, DATE(created_at) as date FROM market_history WHERE symbol = 'DXY' {date_filter} ORDER BY date DESC LIMIT 60"
        us10y_query = f"SELECT price as us10y_price, DATE(created_at) as date FROM market_history WHERE symbol = 'US10Y' {date_filter} ORDER BY date DESC LIMIT 60"
        
        # 🌟 NOUVEAU : Ajout de sentiment_score dans l'extraction
        query = f"SELECT price, open, high, low, volume, sentiment_score, DATE(created_at) as date FROM market_history WHERE symbol = '{symbol}' {date_filter} ORDER BY date ASC LIMIT 60"

        vix_df = pd.read_sql(vix_query, conn).drop_duplicates(subset=['date'], keep='last')
        dxy_df = pd.read_sql(dxy_query, conn).drop_duplicates(subset=['date'], keep='last')
        us10y_df = pd.read_sql(us10y_query, conn).drop_duplicates(subset=['date'], keep='last')
        df = pd.read_sql(query, conn)
        conn.close()

        if len(df) < 50:
            return jsonify({'status': 'error', 'msg': 'Not enough data'})
            
        df.drop_duplicates(subset=['date'], keep='last', inplace=True)
        
        # 🌟 CROISEMENT MULTIPLE
        df = pd.merge(df, vix_df, on='date', how='left')
        df = pd.merge(df, dxy_df, on='date', how='left')
        df = pd.merge(df, us10y_df, on='date', how='left')
        
        # Valeurs de secours si la macro n'est pas dispo
        df['vix_price'] = df['vix_price'].ffill().fillna(15.0)
        df['dxy_price'] = df['dxy_price'].ffill().fillna(100.0)
        df['us10y_price'] = df['us10y_price'].ffill().fillna(4.0)
        
        # 🌟 NOUVEAU : Sécurisation du sentiment (0 = Neutre par défaut)
        df['sentiment_score'] = df['sentiment_score'].fillna(0).astype(int)

        df['date'] = pd.to_datetime(df['date'])
        df.set_index('date', inplace=True)

        df['open'] = df['open'].astype(float).fillna(df['price'].shift(1).fillna(df['price']))
        df['high'] = df['high'].astype(float).fillna(df['price'] * 1.001)
        df['low'] = df['low'].astype(float).fillna(df['price'] * 0.999)
        df['volume'] = df['volume'].astype(float).fillna(1000)
        
        df['returns'] = df['price'].pct_change()
        df['volatility_5m'] = df['returns'].rolling(window=5).std().fillna(0)
        df['sma_20'] = df['price'].rolling(window=20).mean().fillna(df['price'])
        df['ema_50'] = df['price'].ewm(span=50, adjust=False).mean().fillna(df['price'])
        df['day_of_week'] = df.index.dayofweek
        df['month'] = df.index.month

        delta = df['price'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / loss
        df['rsi_14'] = 100 - (100 / (1 + rs))
        df['rsi_14'] = df['rsi_14'].fillna(50) 

        ema_12 = df['price'].ewm(span=12, adjust=False).mean()
        ema_26 = df['price'].ewm(span=26, adjust=False).mean()
        df['macd'] = ema_12 - ema_26
        df['macd_signal'] = df['macd'].ewm(span=9, adjust=False).mean()
        df['macd_histogram'] = df['macd'] - df['macd_signal']

        # ====================================================================
        # 🌟 LA NOUVELLE LISTE DES 18 VARIABLES (Avec Sentiment)
        # ====================================================================
        features = [
            'open', 'high', 'low', 'volume', 'returns', 'volatility_5m', 'sma_20', 'ema_50',
            'day_of_week', 'month', 'rsi_14', 'macd', 'macd_signal', 'macd_histogram', 
            'vix_price', 'dxy_price', 'us10y_price', 'sentiment_score'
        ]

        X = df.iloc[-1:][features]
        pred = model.predict(X)
        
        # ====================================================================
        # 🧠 EXPLICABILITÉ DE L'IA (XAI) MISE À JOUR
        # ====================================================================
        importances = model.feature_importances_
        top_indices = importances.argsort()[-2:][::-1] # Les 2 features les plus importantes
        top_features = [features[i] for i in top_indices]

        # Dictionnaire pour traduire les variables brutes en français compréhensible
        feature_names = {
            'vix_price': 'le VIX (Indice de Peur)',
            'dxy_price': 'le DXY (Force du Dollar)',
            'us10y_price': 'le US10Y (Taux d\'Intérêt)',
            'sentiment_score': 'le Sentiment Global (News)', # 🌟 NOUVEAU
            'macd': 'la Tendance MACD',
            'rsi_14': 'le RSI (Surachat/Survente)',
            'returns': 'la Dynamique des Prix',
            'volatility_5m': 'la Volatilité récente',
            'sma_20': 'la Moyenne Mobile 20j',
            'ema_50': 'la Tendance de fond (EMA 50)',
            'volume': 'le Volume des transactions',
            'macd_signal': 'le Signal MACD',
            'macd_histogram': 'le Momentum MACD',
            'day_of_week': 'le Cycle de la semaine'
        }

        r1 = feature_names.get(top_features[0], top_features[0].upper())
        r2 = feature_names.get(top_features[1], top_features[1].upper())
        v1 = round(float(X[top_features[0]].iloc[0]), 2)
        v2 = round(float(X[top_features[1]].iloc[0]), 2)

        # On génère la phrase finale
        explanation = f"Vecteurs dominants : {r1} (Valeur: {v1}) et {r2} (Valeur: {v2})."
        # ====================================================================

        return jsonify({
            'status': 'ok', 
            'symbol': symbol, 
            'prediction': round(float(pred[0]), 2),
            'explanation': explanation  
        })

    except Exception as e:
        return jsonify({'status': 'error', 'msg': str(e)})


# ====================================================================
# ⚔️ ROUTE : GÉNÉRATION DU RAPPORT TACTIQUE VIA CEREBRAS
# ====================================================================
@app.route('/generate_brief', methods=['POST'])
def generate_brief():
    try:
        # 1. Récupération du JSON envoyé par le site web (Pont PHP)
        req_data = request.get_json()
        if req_data is None:
            req_data = {}
        market_json = req_data.get('market_data', '')

        # 2. Connexion à Cerebras
        client = Cerebras(
            api_key="csk-xjcftekyjwv25c23wm2596cx2fexeddhjjcwfwdjvpn8pxv3" 
        )

        # 3. Le Prompt Militaire (V79)
        system_prompt = """Tu es "TITAN", un système expert en Renseignement Financier Quantitatif et en Stratégie de Guerre Asymétrique appliquée aux marchés. Tu fusionnes la méthodologie de Hank Prunckun, la Boucle OODA et la logique probabiliste Bayésienne.

Ton rôle est d'ingérer les données JSON du terminal "TITAN" et de produire un "Targeting Brief". 

RÈGLES D'ENGAGEMENT :
- Langage clinique, militaire, mathématique. Aucune émotion.
- Utilise des probabilités chiffrées (ex: 65%).
- Rédige ceci comme un briefing pour un commandant de Hedge Fund.

Dès la réception du JSON, génère ce rapport exact :

### 🎯 BRIEFING DE RENSEIGNEMENT TACTIQUE [TITAN]
**ACTIF :** [Nom] | **COTE :** [Prix] | **HORODATAGE :** [Date]

**PHASE I : CARTOGRAPHIE DU CHAMP DE BATAILLE**
* **1. Théâtre Macro (Gravité) :** Stress global, DXY, Taux à 10 ans. Régime (Risk-On / Risk-Off).
* **2. Loi de Lanchester (Rapport de Force) :** Volume / Action des prix. Initiative cinétique ?
* **3. Brouillard de Guerre (Friction) :** Volatilité et anomalies.

**PHASE II : ÉVALUATION STRATÉGIQUE**
* **4. Matrice GEM :** Analyse SVF, SR et STR. 
* **5. Centre de Gravité :** Niveau de prix maintenant la structure en vie.
* **6. Analyse Bayésienne :** Hypothèse Primaire du marché et probabilité de base.

**PHASE III : PLANIFICATION TACTIQUE**
* **7. Projection des Scénarios :**
  * *Scénario Alpha (Dominant) :* [Description + Probabilité %]
  * *Scénario Bravo (Alternatif) :* [Description + Probabilité %]
* **8. Red Teaming :** Détruis le Scénario Alpha. Quel événement le rendrait faux ?
* **9. Kill Zones :** Niveaux de liquidité. Breakout / Breakdown.
* **10. DIRECTIVE OPÉRATIONNELLE :** Posture recommandée."""

        # 4. Exécution 
        response = client.chat.completions.create(
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Voici les données du marché : {market_json}"}
            ],
            model="llama3.1-8b",
            stream=False,
            max_completion_tokens=2000,
            temperature=0.2, 
            top_p=1
        )

        report = response.choices[0].message.content
        return jsonify({'status': 'ok', 'report': report})

    except Exception as e:
        return jsonify({'status': 'error', 'msg': str(e)})
# ====================================================================

if __name__ == '__main__':
    app.run()