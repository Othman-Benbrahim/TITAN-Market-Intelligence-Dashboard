import pymysql
import pandas as pd
import xgboost as xgb
import os
import warnings
warnings.filterwarnings('ignore')

# On calcule le dossier actuel (pour sauvegarder les .json au bon endroit)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

ACTIFS = ['BTCUSDT', 'SPY', 'QQQ', 'GOLD', 'VIX', 'UUP']

print("🔌 Connexion à TITAN...")
conn = pymysql.connect(host='mysql-othman.alwaysdata.net', user='othman', password='Kf6.nLi,B8#$d3Z', database='othman_titan')

# =====================================================================
# 🌟 EXTRACTION DE TOUTE LA MACRO-ÉCONOMIE (VIX, DXY, US10Y)
# =====================================================================
print("🌍 Récupération des données Macro...")
macro_queries = {
    'vix_price': "SELECT price as vix_price, DATE(created_at) as date FROM market_history WHERE symbol = 'VIX'",
    'dxy_price': "SELECT price as dxy_price, DATE(created_at) as date FROM market_history WHERE symbol = 'DXY'",
    'us10y_price': "SELECT price as us10y_price, DATE(created_at) as date FROM market_history WHERE symbol = 'US10Y'"
}

macro_dfs = {}
for name, query in macro_queries.items():
    temp_df = pd.read_sql(query, conn)
    temp_df.drop_duplicates(subset=['date'], keep='last', inplace=True)
    macro_dfs[name] = temp_df

# LA BOUCLE D'ENTRAÎNEMENT
for symbol in ACTIFS:
    print(f"\n⚙️ Traitement de l'actif : {symbol}...")
    
    # 🌟 NOUVEAU : Ajout de 'sentiment_score' dans la requête SQL
    query = f"SELECT price, open, high, low, volume, sentiment_score, DATE(created_at) as date FROM market_history WHERE symbol = '{symbol}' ORDER BY date ASC"
    df = pd.read_sql(query, conn)
    df.drop_duplicates(subset=['date'], keep='last', inplace=True)
    
    if len(df) < 50:
        continue

    # =====================================================================
    # 🌟 CROISEMENT MULTIPLE (Merge de l'actif avec la Macro)
    # =====================================================================
    df = pd.merge(df, macro_dfs['vix_price'], on='date', how='left')
    df = pd.merge(df, macro_dfs['dxy_price'], on='date', how='left')
    df = pd.merge(df, macro_dfs['us10y_price'], on='date', how='left')
    
    # Valeurs de fallback sécurisées (si marché fermé)
    df['vix_price'] = df['vix_price'].ffill().fillna(15.0)
    df['dxy_price'] = df['dxy_price'].ffill().fillna(100.0)
    df['us10y_price'] = df['us10y_price'].ffill().fillna(4.0)
    
    # 🌟 NOUVEAU : Fallback pour le sentiment des anciennes lignes (0 = Neutre)
    df['sentiment_score'] = df['sentiment_score'].fillna(0).astype(int)

    # Temps
    df['date'] = pd.to_datetime(df['date'])
    df.set_index('date', inplace=True)

    # OHLCV Features
    df['open'] = df['open'].astype(float).fillna(df['price'].shift(1).fillna(df['price']))
    df['high'] = df['high'].astype(float).fillna(df['price'] * 1.001)
    df['low'] = df['low'].astype(float).fillna(df['price'] * 0.999)
    df['volume'] = df['volume'].astype(float).fillna(1000)
    
    # Indicateurs
    df['returns'] = df['price'].pct_change()
    df['volatility_5m'] = df['returns'].rolling(window=5).std()
    df['sma_20'] = df['price'].rolling(window=20).mean()
    df['ema_50'] = df['price'].ewm(span=50, adjust=False).mean()

    df['day_of_week'] = df.index.dayofweek
    df['month'] = df.index.month

    delta = df['price'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
    rs = gain / loss
    df['rsi_14'] = 100 - (100 / (1 + rs))

    ema_12 = df['price'].ewm(span=12, adjust=False).mean()
    ema_26 = df['price'].ewm(span=26, adjust=False).mean()
    df['macd'] = ema_12 - ema_26
    df['macd_signal'] = df['macd'].ewm(span=9, adjust=False).mean()
    df['macd_histogram'] = df['macd'] - df['macd_signal']

    df['target_price'] = df['price'].shift(-1)
    df.dropna(inplace=True)

    # =====================================================================
    # 🧠 LE NOUVEAU CERVEAU : 18 VARIABLES (Intégration du Sentiment NLP)
    # =====================================================================
    features = [
        'open', 'high', 'low', 'volume', 'returns', 'volatility_5m', 'sma_20', 'ema_50',
        'day_of_week', 'month', 'rsi_14', 'macd', 'macd_signal', 'macd_histogram', 
        'vix_price', 'dxy_price', 'us10y_price', 'sentiment_score' # 🌟 NOUVELLE VARIABLE ICI
    ]
    
    X = df[features]
    y = df['target_price']

    model = xgb.XGBRegressor(n_estimators=100, learning_rate=0.05, max_depth=4, objective='reg:squarederror')
    model.fit(X, y)

    # 🚨 SAUVEGARDE DIRECTE SUR LE SERVEUR
    filename = f"{symbol.lower()}_xgboost_model.json"
    filepath = os.path.join(BASE_DIR, filename)
    model.save_model(filepath)
    print(f"✅ Cerveau {symbol} mis à jour (MACRO + NLP INTÉGRÉS) : {filename}")

    # =====================================================================
    # 📊 LE BULLETIN DE NOTES : ENREGISTREMENT DE LA PRÉDICTION DE DEMAIN
    # =====================================================================
    try:
        # On prend la toute dernière ligne des données (aujourd'hui)
        X_today = df.iloc[-1:][features]
        # L'IA fait sa prédiction pour demain
        pred_tomorrow = float(model.predict(X_today)[0])
        
        # On calcule les dates
        today_date = pd.Timestamp.today().strftime('%Y-%m-%d')
        target_date = (pd.Timestamp.today() + pd.Timedelta(days=1)).strftime('%Y-%m-%d')
        
        # On enregistre dans la base de données
        cursor = conn.cursor()
        sql_insert = """
            INSERT INTO ai_predictions (symbol, prediction_date, target_date, predicted_price) 
            VALUES (%s, %s, %s, %s) 
            ON DUPLICATE KEY UPDATE predicted_price = VALUES(predicted_price)
        """
        cursor.execute(sql_insert, (symbol, today_date, target_date, pred_tomorrow))
        conn.commit()
        print(f"📝 Prédiction enregistrée pour le {target_date} : {round(pred_tomorrow, 2)}$")
    except Exception as e:
        print(f"❌ Erreur lors de l'enregistrement de la prédiction : {e}")
    # =====================================================================

conn.close()
print("🏆 ENTRAÎNEMENT TERMINÉ ! Les modèles sont à jour sur le serveur.")