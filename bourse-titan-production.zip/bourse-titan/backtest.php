<?php
// backtest.php - LABORATOIRE DE BACKTESTING TITAN (V5 - HYBRID IA READY)
ini_set('display_errors', 0);
require_once 'db.php';

$symbol = $_GET['symbol'] ?? 'BTCUSDT';
$offset_days = (int)($_GET['offset'] ?? 30); 

// Configurations
$assets_config = ['SPY' => 1.0, 'QQQ' => 1.2, 'BTCUSDT' => 1.5, 'GOLD' => -0.4, 'VIX' => -2.0];
$beta = $assets_config[$symbol] ?? 1.0;

// 1. Récupération de TOUT l'historique
$stmt = $pdo->prepare("SELECT price, DATE(created_at) as day FROM market_history WHERE symbol = ? ORDER BY created_at ASC");
$stmt->execute([$symbol]);
$all_rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

$daily = [];
foreach ($all_rows as $r) { $daily[$r['day']] = (float)$r['price']; }
ksort($daily);
$dates = array_keys($daily);
$prices = array_values($daily);
$total_days = count($prices);

if ($total_days < $offset_days + 10) {
    die("<h3 style='color:white; font-family:monospace;'>Pas assez d'historique pour remonter de $offset_days jours.</h3>");
}

// 2. COUPURE DE LA LIGNE DU TEMPS 
$split_index = $total_days - $offset_days;
$training_prices = array_slice($prices, 0, $split_index); 
$actual_future_prices = array_slice($prices, $split_index); 
$training_dates = array_slice($dates, 0, $split_index);
$actual_future_dates = array_slice($dates, $split_index);

$last_known_price = end($training_prices);
$split_date = end($training_dates); // La date exacte où on coupe le temps
$stress = 50; 

// =========================================================================
// 🧠 NOUVEAU : INTERROGATION DU CORTEX ET DE L'API PYTHON DANS LE PASSÉ
// =========================================================================
$stmt_ai = $pdo->prepare("SELECT weight_oracle, weight_echo FROM titan_cortex WHERE symbol = ?");
$stmt_ai->execute([$symbol]);
$ai_brain = $stmt_ai->fetch(PDO::FETCH_ASSOC);
$w_oracle = $ai_brain ? (float)$ai_brain['weight_oracle'] : 0.5;
$w_echo   = $ai_brain ? (float)$ai_brain['weight_echo'] : 0.5;

$ml_prediction = null;
$api_url = "http://api.visiondufutur.com/predict/" . $symbol . "?date=" . $split_date; 
$ctx = stream_context_create(['http' => ['timeout' => 2.0]]); 
$response = @file_get_contents($api_url, false, $ctx);
if ($response) {
    $ml_data = json_decode($response, true);
    if (isset($ml_data['status']) && $ml_data['status'] === 'ok') {
        $ml_prediction = (float)$ml_data['prediction'];
    }
}
// =========================================================================

// 3. CALCUL DE L'ECHO FRACTAL 
$pattern_size = 5;
$echo_future_prices = [];
if (count($training_prices) >= $pattern_size + $offset_days) {
    $current_shape = array_slice($training_prices, -$pattern_size);
    $base_curr = $current_shape[0] ?: 1;
    $norm_curr = array_map(function($p) use ($base_curr) { return $p / $base_curr; }, $current_shape);

    $best_dist = INF; $best_idx = -1;
    $limit = count($training_prices) - $pattern_size - $offset_days;
    for ($i = 0; $i <= $limit; $i++) {
        $window = array_slice($training_prices, $i, $pattern_size);
        $base_win = $window[0];
        if ($base_win == 0) continue;
        
        $norm_win = array_map(function($p) use ($base_win) { return $p / $base_win; }, $window);
        $dist = 0;
        for ($j=0; $j<$pattern_size; $j++) $dist += pow($norm_curr[$j] - $norm_win[$j], 2);
        if ($dist < $best_dist) { $best_dist = $dist; $best_idx = $i; }
    }

    $pivot_hist = $training_prices[$best_idx + $pattern_size - 1];
    if ($pivot_hist > 0) {
        for ($k = 1; $k <= $offset_days; $k++) {
            $ref_price = $training_prices[$best_idx + $pattern_size - 1 + $k];
            $pct_change = ($ref_price - $pivot_hist) / $pivot_hist;
            $echo_future_prices[] = $last_known_price * (1 + $pct_change);
        }
    }
}
if (empty($echo_future_prices)) { for ($k=0; $k<$offset_days; $k++) $echo_future_prices[] = $last_known_price; }

// 4. CALCUL DE L'ORACLE ET DE L'HYBRIDE IA
$inertia = 0;
if (count($training_prices) >= 5) {
    $first = $training_prices[count($training_prices)-5];
    if ($first != 0) $inertia = (($last_known_price - $first) / $first) * 0.3;
}
$macro_force = (50 - $stress) / 1000;
$daily_drift = ($inertia + ($macro_force * $beta)) / 3;
$volatility = $stress / 8000; 

$oracle_future_prices = [];
$hybrid_future_prices = []; // NOUVEAU
$current_oracle = $last_known_price;
$ml_offset = 0;

mt_srand(crc32($symbol) + $offset_days);

for ($k = 1; $k <= $offset_days; $k++) {
    // Calcul Oracle
    $decay = 1 / sqrt($k);
    $noise = (mt_rand(-100, 100) / 100) * $volatility * abs($beta); 
    $move = ($daily_drift * $decay) + $noise;
    $current_oracle = $current_oracle * (1 + $move);
    $oracle_future_prices[] = $current_oracle;
    
    // NOUVEAU : Calcul de la fusion Hybride
    $val_echo = $echo_future_prices[$k-1];
    $val_hybrid = ($current_oracle * $w_oracle) + ($val_echo * $w_echo);

    if ($ml_prediction !== null) {
        if ($k == 1) {
            $ml_offset = $ml_prediction - $val_hybrid;
        }
        $val_hybrid = $val_hybrid + ($ml_offset / sqrt($k));
    }
    $hybrid_future_prices[] = $val_hybrid;
}

// 5. PRÉPARATION DES DONNÉES
$out_labels = array_merge(array_slice($training_dates, -30), $actual_future_dates);
$out_real = array_merge(array_slice($training_prices, -30), $actual_future_prices);

$out_oracle = array_fill(0, 30, null);
$out_oracle[29] = $last_known_price; 
$out_oracle = array_merge($out_oracle, $oracle_future_prices);

$out_echo = array_fill(0, 30, null);
$out_echo[29] = $last_known_price; 
$out_echo = array_merge($out_echo, $echo_future_prices);

$out_hybrid = array_fill(0, 30, null);
$out_hybrid[29] = $last_known_price; 
$out_hybrid = array_merge($out_hybrid, $hybrid_future_prices);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>TITAN | BACKTESTING IA</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { background: #020305; color: #cfcfcf; font-family: monospace; padding: 20px; }
        .panel { background: #111; border: 1px solid #333; padding: 20px; border-radius: 5px; }
        select, input, button { background: #000; color: #00f3ff; border: 1px solid #00f3ff; padding: 5px 10px; font-family: monospace; }
        button { cursor: pointer; background: rgba(0,243,255,0.1); border: 1px solid #00f3ff; color: #00f3ff; margin-right: 10px;}
        button:hover { background: #00f3ff; color: #000; }
        .export-btn { border-color: #00ff9d; color: #00ff9d; background: rgba(0, 255, 157, 0.1); }
        .export-btn:hover { background: #00ff9d; color: #000; }
        .ai-status { padding: 5px 10px; border-radius: 3px; font-weight: bold; margin-left: 20px; font-size: 0.9em; }
    </style>
</head>
<body>
    <div class="panel">
        <h2 style="color: #00ff9d; margin-top:0;">⏱️ TITAN TIME MACHINE (BACKTEST HYBRIDE IA)</h2>
        <p>Ce module force l'IA à retourner dans le passé pour générer une prédiction, et la superpose avec la véritable histoire pour vérifier sa précision.</p>
        
        <form method="GET" style="display:inline-block; margin-bottom: 10px;">
            <label>Actif : </label>
            <select name="symbol">
                <option value="BTCUSDT" <?= $symbol=='BTCUSDT'?'selected':'' ?>>BITCOIN</option>
                <option value="SPY" <?= $symbol=='SPY'?'selected':'' ?>>SPY</option>
                <option value="GOLD" <?= $symbol=='GOLD'?'selected':'' ?>>GOLD</option>
            </select>
            
            <label style="margin-left:20px;">Remonter de : </label>
            <input type="number" name="offset" value="<?= $offset_days ?>" min="5" max="60" style="width:60px;"> jours.
            
            <button type="submit" style="margin-left:20px;">LANCER LA SIMULATION</button>
            
            <?php if($ml_prediction !== null): ?>
                <span class="ai-status" style="background: rgba(0, 255, 157, 0.1); color: #00ff9d; border: 1px solid #00ff9d;">🧠 IA XGBOOST CONNECTÉE</span>
            <?php else: ?>
                <span class="ai-status" style="background: rgba(255, 42, 109, 0.1); color: #ff2a6d; border: 1px solid #ff2a6d;">⚠️ IA HORS LIGNE (ORACLE SEUL)</span>
            <?php endif; ?>
        </form>

        <div style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #333;">
            <span style="color:#666; font-size: 0.8em; margin-right: 10px;">DATA EXPORT (ML READY):</span>
            <button onclick="downloadJSON()" class="export-btn">⬇️ DOWNLOAD JSON</button>
            <button onclick="downloadCSV()" class="export-btn">⬇️ DOWNLOAD CSV</button>
        </div>
    </div>

    <div class="panel" style="margin-top:20px; height: 500px;">
        <canvas id="backtestChart"></canvas>
    </div>

    <script>
        const labels = <?= json_encode($out_labels) ?>;
        const realData = <?= json_encode($out_real) ?>;
        const oracleData = <?= json_encode($out_oracle) ?>;
        const echoData = <?= json_encode($out_echo) ?>;
        const hybridData = <?= json_encode($out_hybrid) ?>;
        const symbol = "<?= $symbol ?>";
        const offset = <?= $offset_days ?>;

        function getCleanData() {
            let data = [];
            for(let i = 0; i < labels.length; i++) {
                data.push({
                    "date": labels[i],
                    "symbol": symbol,
                    "price_real": realData[i],
                    "pred_oracle": oracleData[i],
                    "pred_echo": echoData[i],
                    "pred_hybrid": hybridData[i]
                });
            }
            return data;
        }

        function downloadJSON() {
            const data = getCleanData();
            const fileName = `TITAN_BACKTEST_IA_${symbol}_${offset}d.json`;
            const jsonStr = JSON.stringify(data, null, 4);
            const blob = new Blob([jsonStr], { type: "application/json" });
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url; a.download = fileName; document.body.appendChild(a); a.click(); document.body.removeChild(a);
        }

        function downloadCSV() {
            const data = getCleanData();
            const fileName = `TITAN_BACKTEST_IA_${symbol}_${offset}d.csv`;
            let csvContent = "Date,Symbol,Real_Price,Oracle_Prediction,Echo_Prediction,Hybrid_IA_Prediction\n";
            data.forEach(row => {
                const oracleVal = row.pred_oracle !== null ? row.pred_oracle : "";
                const echoVal = row.pred_echo !== null ? row.pred_echo : "";
                const hybridVal = row.pred_hybrid !== null ? row.pred_hybrid : "";
                csvContent += `${row.date},${row.symbol},${row.price_real},${oracleVal},${echoVal},${hybridVal}\n`;
            });
            const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url; a.download = fileName; document.body.appendChild(a); a.click(); document.body.removeChild(a);
        }

        const ctx = document.getElementById('backtestChart').getContext('2d');
        Chart.defaults.color = '#666'; Chart.defaults.font.family = 'monospace';
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    { label: 'RÉALITÉ (Target)', data: realData, borderColor: '#00f3ff', borderWidth: 2, pointRadius: 0, fill:true, backgroundColor:'rgba(0,243,255,0.05)' },
                    { label: 'ORACLE (Macro)', data: oracleData, borderColor: '#ffc800', borderWidth: 1, borderDash: [5, 5], pointRadius: 0 },
                    { label: 'ECHO (Fractal)', data: echoData, borderColor: '#bd00ff', borderWidth: 1, borderDash: [2, 4], pointRadius: 0 },
                    { label: 'TITAN AI (Hybride)', data: hybridData, borderColor: '#ffffff', borderWidth: 3, tension: 0.2, pointRadius: 0, shadowBlur: 10, shadowColor: 'white' }
                ]
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                interaction: { mode: 'index', intersect: false },
                plugins: {
                    annotation: {
                        annotations: {
                            line1: { type: 'line', xMin: 29, xMax: 29, borderColor: 'rgba(255,0,0,0.5)', borderWidth: 2, label: { content: 'COUPURE MÉMOIRE (-' + offset + 'j)', enabled: true, position: 'top' } }
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>