<?php
// index.php - V83 "PRO TERMINAL + ORDER BOOK X-RAY + LLM + DYNAMIC XAI + SMART MONEY"
ini_set('display_errors', 0);
date_default_timezone_set('Europe/Paris');
try { require_once 'db.php'; } catch (Exception $e) { die("Erreur DB"); }

// Fonction Sparkline (SVG)
function drawSparkline($pdo, $symbol, $color) {
    try {
        $stmt = $pdo->prepare("SELECT price FROM market_history WHERE symbol = ? ORDER BY created_at DESC LIMIT 20");
        $stmt->execute([$symbol]);
        $data = $stmt->fetchAll(PDO::FETCH_COLUMN);
        if (count($data) < 2) return "";
        $data = array_reverse($data);
        $min = min($data); $max = max($data); $range = $max - $min; if ($range == 0) $range = 1;
        $width = 40; $height = 18; $step = $width / (count($data) - 1);
        $points = "";
        foreach ($data as $i => $val) {
            $x = $i * $step; $y = $height - (($val - $min) / $range * $height);
            $points .= "$x,$y ";
        }
        return "<svg width='$width' height='$height' style='margin-left:5px; opacity:0.8'><polyline points='$points' fill='none' stroke='$color' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/></svg>";
    } catch (Exception $e) { return ""; }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TITAN | V83 AI-CORTEX</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700&family=Rajdhani:wght@600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root { --bg: #020305; --card: rgba(14, 16, 21, 0.96); --brd: 1px solid rgba(255, 255, 255, 0.08); --red: #ff2a6d; --blue: #00f3ff; --green: #00ff9d; --gold: #ffc800; --purple: #bd00ff; --white: #ffffff; }
        body { background: var(--bg); color: #cfcfcf; font-family: 'JetBrains Mono', monospace; font-size: 0.7rem; padding-bottom: 60px; overflow-x: hidden; }
        
        .top-bar { padding: 8px 20px; border-bottom: var(--brd); background: rgba(5,5,5,0.98); display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 999; }
        .logo { font-family: 'Rajdhani', sans-serif; font-size: 1.6rem; font-weight: bold; letter-spacing: 2px; color: #fff; text-transform: uppercase; }
        
        .news-wire { background: #000; border-bottom: 1px solid #222; height: 30px; display: flex; align-items: center; overflow: hidden; white-space: nowrap; position: relative; }
        .news-label { background: var(--gold); color: #000; padding: 0 15px; font-weight: bold; font-size: 0.6rem; height: 100%; display: flex; align-items: center; z-index: 20; position: absolute; left: 0; }
        .news-scroll { display: inline-block; padding-left: 100%; animation: scroll-news 50s linear infinite; }
        .news-item { display: inline-block; padding: 0 40px; font-size: 0.65rem; color: #888; border-right: 1px solid #222; }
        .news-item.alert { color: var(--red); font-weight: bold; text-shadow: 0 0 10px rgba(255,42,109,0.3); }
        @keyframes scroll-news { 0% { transform: translateX(0); } 100% { transform: translateX(-150%); } }

        .grid-container { display: grid; grid-template-columns: repeat(auto-fit, minmax(380px, 1fr)); gap: 15px; padding: 15px; }
        .cyber-card { background: var(--card); border: var(--brd); border-radius: 4px; min-height: 240px; display: flex; flex-direction: column; overflow: hidden; position: relative; backdrop-filter: blur(15px); }
        .card-header { padding: 12px 15px; font-family: 'Rajdhani', sans-serif; font-weight: 700; border-bottom: var(--brd); display: flex; justify-content: space-between; align-items: center; background: rgba(255,255,255,0.03); font-size: 0.9rem; letter-spacing: 1px; }
        .card-body { flex: 1; overflow-y: auto; padding: 0; }
        .card-full { grid-column: 1 / -1; }
        .chart-container { position: relative; height: 320px; width: 100%; padding: 10px; }
        .shield-display { padding: 40px 20px; text-align: center; border-bottom: var(--brd); }
        .shield-gauge { font-size: 4rem; font-family: 'Rajdhani'; font-weight: 800; line-height: 1; text-shadow: 0 0 30px rgba(0,243,255,0.1); transition: 0.5s; }
        .directive-label { font-size: 1.1rem; font-weight: bold; letter-spacing: 2px; font-family: 'Rajdhani'; margin-top: 10px; }
        .data-row { display: flex; justify-content: space-between; padding: 10px 15px; border-bottom: 1px solid rgba(255,255,255,0.03); }
        .hud-bar { position: fixed; bottom: 0; left: 0; width: 100%; height: 40px; background: #000; border-top: 1px solid #333; display: flex; align-items: center; z-index: 9999; }
        .hud-sec { padding: 0 20px; height: 100%; display: flex; align-items: center; border-right: 1px solid #222; }
        .defcon-active { background: var(--red); color: #fff; font-weight: bold; animation: pulse 1s infinite; }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }
        .pulse-critical { animation: pulse-border 1.5s infinite alternate; border: 1px solid var(--red); }
        @keyframes pulse-border { 0% { box-shadow: 0 0 5px var(--red); } 100% { box-shadow: 0 0 20px var(--red); } }
        
        .asset-selector { background: #111; border: 1px solid #333; color: #fff; padding: 5px 10px; border-radius: 4px; font-family: 'JetBrains Mono'; font-size: 0.8rem; cursor: pointer; }
        .asset-selector:focus { outline: none; border-color: var(--blue); }
        
        .mini-action-btn { 
            background: rgba(0, 243, 255, 0.1); 
            border: 1px solid var(--blue); 
            color: var(--blue); 
            font-family: 'JetBrains Mono'; font-size: 0.6rem; font-weight: bold;
            padding: 4px 8px; border-radius: 4px; 
            cursor: pointer; margin-left: 10px; transition: 0.2s; 
        }
        .mini-action-btn:hover { background: var(--blue); color: #000; }
        .mini-action-btn.copied { border-color: var(--green); color: var(--green); background: rgba(0, 255, 157, 0.1); }

        .gem-table { width: 100%; border-collapse: collapse; font-size: 0.65rem; }
        .gem-table th { color: #888; font-weight: normal; text-align: left; padding: 8px 15px; border-bottom: 1px solid #222; }
        .gem-table td { padding: 8px 15px; border-bottom: 1px solid #111; color: #ddd; }
        .gem-score-box { background: rgba(255,255,255,0.05); border: 1px solid #333; padding: 10px; text-align: center; border-radius: 4px; }
        .gem-score-val { font-size: 1.2rem; font-weight: bold; font-family: 'Rajdhani'; }

        .status-led { width: 8px; height: 8px; border-radius: 50%; display: inline-block; margin-right: 5px; box-shadow: 0 0 10px currentColor; transition: 0.3s; }
        .led-healthy { color: var(--green); background: var(--green); }
        .led-warning { color: var(--gold); background: var(--gold); }
        .led-stale { color: var(--red); background: var(--red); }
        .corr-box { text-align: center; padding: 15px; border-top: 1px solid rgba(255,255,255,0.05); }
        .corr-value { font-size: 2rem; font-family: 'Rajdhani'; font-weight: 800; line-height: 1; }
        .bar-bg { background: #111; height: 6px; border-radius: 3px; overflow: hidden; margin-top: 5px; border: 1px solid #222; }
        .bar-fill { height: 100%; width: 0%; transition: width 1s cubic-bezier(0.1, 0, 0.3, 1); }

        /* CSS pour le radar des Kill Zones */
        .kill-zone-box { border: 1px solid #333; background: #0a0a0a; padding: 8px; text-align: center; border-radius: 4px; flex: 1;}
        .kz-label { font-size: 0.55rem; color: #888; }
        .kz-price { font-size: 1.1rem; font-family: 'Rajdhani'; font-weight: bold; }
    </style>
</head>
<body>

    <div class="top-bar">
        <div class="logo">TITAN <span style="color:var(--gold)">V83 AI</span></div>
        <div class="d-flex align-items-center gap-3">
            <a href="backtest.php" target="_blank" class="btn btn-outline-warning btn-sm" style="font-size:0.6rem;">🧪 BACKTEST</a>
            <a href="public.php" target="_blank" class="btn btn-outline-light btn-sm" style="font-size:0.6rem;">🌍 PUBLIC</a>
            <button id="btn-export" onclick="exportToAI()" class="btn btn-outline-info btn-sm" style="font-size:0.6rem;">📋 COPY_JSON</button>
            <div id="sync-status" style="color:var(--green)">● ONLINE</div>
            <div style="font-family:'JetBrains Mono'; border-left: 1px solid #333; padding-left: 15px;"><?= date('H:i') ?> <span style="color:#666">PARIS</span></div>
        </div>
    </div>

    <div class="news-wire">
        <div class="news-label">WIRE_LIVE</div>
        <div class="news-scroll" id="news-scroll">
            <span class="news-item">INITIALIZING GLOBAL NEWS FEED...</span>
        </div>
    </div>

    <div class="grid-container">

        <div class="cyber-card" id="shield-card" style="min-height: auto;">
            <div class="card-header" style="color:var(--blue)"><span>RISK SHIELD</span><span id="regime-status">SYNC</span></div>
            <div class="shield-display">
                <div class="shield-gauge" id="stress-display">--%</div>
                <div class="directive-label" id="directive-display">ANALYZING...</div>
                
                <div style="margin-top: 20px; border-top: 1px solid rgba(255,255,255,0.05); padding-top: 15px;">
                    <div style="font-size: 0.6rem; color: #888; margin-bottom: 5px;">RÉGIME MACRO-ÉCONOMIQUE (DXY/US10Y)</div>
                    <div id="macro-regime" style="font-size: 1.3rem; font-family: 'Rajdhani'; font-weight: bold; color: #fff; letter-spacing: 1px;">--</div>
                    <div id="macro-desc" style="font-size: 0.65rem; color: #666; margin-top: 3px;">CALCUL DES FLUX...</div>
                    
                    <div class="d-flex justify-content-center gap-3 mt-2" style="font-size: 0.7rem; font-family: 'JetBrains Mono';">
                        <span id="macro-dxy" style="background:rgba(255,255,255,0.03); padding:3px 8px; border-radius:4px;">DXY: --%</span>
                        <span id="macro-us10y" style="background:rgba(255,255,255,0.03); padding:3px 8px; border-radius:4px;">US10Y: --%</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="cyber-card card-full" style="min-height: 350px;">
            <div class="card-header" style="color:var(--gold)">
                <div class="d-flex align-items-center">
                    <div id="data-heartbeat" class="status-led led-healthy" title="Data Freshness"></div>
                    <span class="me-3">TITAN ORACLE</span>
                    <select id="pro-asset-select" class="asset-selector" onchange="refreshChart()">
                        <option value="SPY">SPY (S&P 500)</option>
                        <option value="QQQ">QQQ (Nasdaq)</option>
                        <option value="BTCUSDT">BITCOIN</option>
                        <option value="GOLD">OR (Gold)</option>
                        <option value="VIX">VIX (Volatilité)</option>
                    </select>
                    <button onclick="copyAssetJSON()" id="btn-asset-pro" class="mini-action-btn">[ REPORT_JSON ]</button>
                </div>
                <span style="font-size:0.7rem; color:#666">TIMEFRAME: <b style="color:#fff">1 MOIS</b></span>
            </div>
            
            <div class="d-flex gap-2" style="padding: 10px 15px; border-bottom: 1px solid rgba(255,255,255,0.05); background: rgba(0,0,0,0.5);">
                <div class="kill-zone-box">
                    <div class="kz-label">KILL ZONE (BREAKOUT) 🎯</div>
                    <div class="kz-price" id="kz-up" style="color:var(--red)">-- $</div>
                </div>
                <div style="display:flex; align-items:center; color:#555; font-size:0.6rem;" id="kz-type">[SCANNING ORDER BOOK...]</div>
                <div class="kill-zone-box">
                    <div class="kz-label">KILL ZONE (SUPPORT) 🛡️</div>
                    <div class="kz-price" id="kz-down" style="color:var(--green)">-- $</div>
                </div>
            </div>

            <div class="chart-container"><canvas id="oracleChart"></canvas></div>
            
            <div style="margin: 0px 15px 15px 15px; padding: 10px 15px; background: rgba(255, 200, 0, 0.05); border-left: 2px solid var(--gold); border-radius: 4px;">
                <p style="margin: 0; font-size: 0.6rem; color: #888; font-family: 'JetBrains Mono', monospace; line-height: 1.5;">
                    <span style="color: var(--white); font-weight: bold;">[🧠] AI INSIGHT :</span> <span id="ai-insight" style="color: var(--blue);">ANALYSE EN COURS...</span>
                </p>
            </div>
        </div>

        <div class="cyber-card">
            <div class="card-header" style="color:var(--purple)"><span>GEM MATRICE PRUNCKUN</span><span id="gem-reading" style="color:#fff">...</span></div>
            <div class="card-body">
                <div class="d-flex justify-content-between" style="padding:15px; border-bottom:1px solid #222;">
                    <div class="gem-score-box" style="flex:1; margin-right:10px;">
                        <div style="color:#888; font-size:0.55rem; margin-bottom:5px;">SVF (VECTEUR FLUX)</div>
                        <div class="gem-score-val" id="gem-svf" style="color:var(--blue)">--</div>
                    </div>
                    <div class="gem-score-box" style="flex:1; margin-right:10px;">
                        <div style="color:#888; font-size:0.55rem; margin-bottom:5px;">SR (ROBUSTESSE)</div>
                        <div class="gem-score-val" id="gem-sr" style="color:var(--green)">--/5</div>
                    </div>
                    <div class="gem-score-box" style="flex:1;">
                        <div style="color:#888; font-size:0.55rem; margin-bottom:5px;">STR (TENSION)</div>
                        <div class="gem-score-val" id="gem-str" style="color:var(--red)">--/5</div>
                    </div>
                </div>

                <table class="gem-table">
                    <tr>
                        <th style="width:30%">SCÉNARIO</th>
                        <th style="width:50%">DRIVERS (MOTEURS)</th>
                        <th style="width:20%; text-align:right;">PROBA. (AI)</th>
                    </tr>
                    <tr>
                        <td><span style="color:var(--gold)">■ CENTRAL</span><br><span style="font-size:0.5rem; color:#666">ORACLE (MACRO)</span></td>
                        <td>Inertie + Drift</td>
                        <td style="text-align:right; font-weight:bold; color:#fff" id="prob-cen">--%</td>
                    </tr>
                    <tr>
                        <td><span style="color:var(--purple)">■ ALTERNATIF</span><br><span style="font-size:0.5rem; color:#666">ECHO (FRACTAL)</span></td>
                        <td>Pattern Matching</td>
                        <td style="text-align:right; font-weight:bold; color:#fff" id="prob-alt">--%</td>
                    </tr>
                    <tr>
                        <td><span style="color:var(--white)">■ SYNTHÈSE</span><br><span style="font-size:0.5rem; color:#666">HYBRIDE IA</span></td>
                        <td>Optimisation ML</td>
                        <td style="text-align:right; font-weight:bold; color:#fff">100%</td>
                    </tr>
                </table>
            </div>
        </div>
        
        <div class="cyber-card">
            <div class="card-header" style="color:var(--gold)">
                <span>GLOBAL INTELLIGENCE</span>
                <span style="font-size:0.6rem; background:rgba(255,200,0,0.1); padding:2px 6px; border-radius:4px;">ATLAS FLUX</span>
            </div>
            <div class="card-body" style="padding:10px; overflow-y:auto; max-height:220px;" id="osint-feed">
                <div style="color:#666; font-size:0.6rem; text-align:center; margin-top:20px;">[ INITIALIZING OSINT FEED... ]</div>
            </div>
        </div>

        <div class="cyber-card">
            <div class="card-header" style="color:var(--green)">
                <span>🐋 SMART MONEY TRACKER</span>
                <span style="font-size:0.6rem; background:rgba(0, 255, 157, 0.1); padding:2px 6px; border-radius:4px;">FINNHUB API</span>
            </div>
            <div class="card-body corr-box">
                <div id="sm-consensus" style="font-size: 1.2rem; font-family: 'Rajdhani'; font-weight: 800; color: #fff; margin-bottom: 10px;">ANALYSE EN COURS...</div>
                
                <div id="sm-data-box" style="display: none;">
                    <div class="d-flex justify-content-between" style="font-size:0.6rem; color:#888; margin-bottom:3px;">
                        <span>BULLISH (ACHAT)</span>
                        <span>BEARISH (VENTE)</span>
                    </div>
                    <div style="background: #111; height: 10px; border-radius: 5px; overflow: hidden; display: flex; border: 1px solid #222;">
                        <div id="sm-bar-bull" style="background: var(--green); width: 0%; transition: width 1s;"></div>
                        <div id="sm-bar-bear" style="background: var(--red); width: 0%; transition: width 1s;"></div>
                    </div>
                    <div class="d-flex justify-content-between mt-1" style="font-size: 0.7rem; font-weight: bold; font-family: 'JetBrains Mono';">
                        <span id="sm-val-bull" style="color: var(--green);">0%</span>
                        <span id="sm-val-bear" style="color: var(--red);">0%</span>
                    </div>
                    <div style="margin-top: 15px; font-size: 0.6rem; color: #666;">
                        BASÉ SUR L'ANALYSE DE <span id="sm-analysts" style="color:#fff;">0</span> INSTITUTIONS FINANCIÈRES
                    </div>
                </div>
                <div id="sm-error-box" style="font-size: 0.7rem; color: #666; margin-top: 15px;">[ EN ATTENTE DES DONNÉES ]</div>
            </div>
        </div>

        <div class="cyber-card">
            <div class="card-header" style="color:var(--blue)"><span>BENCHMARK CORRELATION</span><span>VS SPY</span></div>
            <div class="card-body corr-box">
                <div class="corr-value" id="corr-coeff">0.00</div>
                <div style="font-size:0.6rem; color:#666; margin-top:5px; text-transform:uppercase;" id="corr-desc">ANALYZING COUPLING...</div>
                
                <div style="margin-top:15px; text-align:left; font-size:0.6rem; padding: 0 10px;">
                    <div class="d-flex justify-content-between"><span>DATA AGE:</span><span id="data-age">-- min</span></div>
                    <div class="bar-bg"><div class="bar-fill" id="bar-age" style="background:var(--blue); width:0%"></div></div>
                </div>
            </div>
        </div>

        <div class="cyber-card">
            <div class="card-header" style="color:var(--blue)"><span>ASSET MONITOR</span><span style="color:var(--green)">● LIVE</span></div>
            <div class="card-body">
                <?php 
                $stmt = $pdo->query("SELECT * FROM market_data ORDER BY change_percent DESC");
                while($r = $stmt->fetch()){
                    $change = (float)$r['change_percent']; $price = (float)$r['price']; $sym = $r['symbol'];
                    $c = $change >= 0 ? 'var(--green)' : 'var(--red)';
                    $sign = $change >= 0 ? '+' : ''; $nameColor = (in_array($sym, ['SPY','QQQ','BTCUSDT']) ? '#fff' : ($sym=='VIX'?'var(--gold)':'#888'));
                    $spark = drawSparkline($pdo, $sym, $c);
                    echo "<div class='data-row'>
                            <span style='color:$nameColor; font-size:0.7rem; font-weight:".($nameColor=='#fff'?'bold':'normal')."'>$sym</span>
                            <div style='display:flex; align-items:center;'>
                                <span style='font-size:0.7rem; color:#ccc;'>".number_format($price, 2)."</span>
                                <span style='font-size:0.7rem; color:$c; margin-left:8px; min-width:45px; text-align:right;'>$sign".number_format($change, 2)."%</span>
                                $spark
                            </div>
                          </div>";
                } ?>
            </div>
        </div>

        <div class="cyber-card">
            <div class="card-header" style="color:var(--green)"><span>STRATEGY PERFORMANCE</span><span>WIN RATE HISTORY</span></div>
            <div class="card-body" style="padding:10px;">
                <div style="height:120px; width:100%;"><canvas id="winRateChart"></canvas></div>
                <div id="perf-stats" class="d-flex justify-content-around mt-2 text-center"></div>
                <div style="font-size:0.6rem; color:#555; margin: 10px 0 5px 5px; border-top:1px solid #222; padding-top:5px;">RECENT SIGNALS:</div>
                <div style="max-height:80px; overflow-y:auto; padding: 0 10px;">
                    <?php
                    $history = $pdo->query("SELECT * FROM titan_performance ORDER BY id DESC LIMIT 5")->fetchAll();
                    foreach($history as $h) {
                        $p_color = $h['pnl_percent'] >= 0 ? 'var(--green)' : 'var(--red)';
                        $p_text = $h['status'] == 'OPEN' ? 'OPEN' : round($h['pnl_percent'], 2) . '%';
                        echo "<div class='d-flex justify-content-between py-1' style='font-size:0.6rem; border-bottom: 1px solid #111;'>
                                <span style='color:".($h['signal_type']=='RED'?'var(--red)':'var(--green)')."'>{$h['signal_type']}</span>
                                <span style='color:#666'>".date('H:i', strtotime($h['entry_time']))."</span>
                                <span style='color:$p_color'>$p_text</span>
                              </div>";
                    }
                    ?>
                </div>
            </div>
        </div>

        <div class="cyber-card card-full" style="min-height: auto; border: 1px solid var(--blue); box-shadow: 0 0 15px rgba(0, 243, 255, 0.1);">
            <div class="card-header" style="color:var(--white); background: rgba(0, 243, 255, 0.05);">
                <div class="d-flex justify-content-between w-100">
                    <span>⚔️ TACTICAL COMMAND (LLM CORTEX)</span>
                    <span style="font-size:0.6rem; color:var(--green);">● SECURE STATIC CACHE</span>
                </div>
            </div>
            <div class="card-body" style="padding:20px; font-family: 'JetBrains Mono'; font-size: 0.75rem; line-height: 1.6; white-space: pre-wrap;" id="llm-report-box">
                <span style="color:#666;">[ CHARGEMENT DU BRIEFING NOCTURNE... ]</span>
            </div>
        </div>

        <div class="cyber-card card-full" style="min-height: auto;">
            <div class="card-header" style="color:var(--blue)">
                <span>🤖 AI PREDICTION PERFORMANCE</span>
                <span style="font-size:0.6rem; background:rgba(0, 243, 255, 0.1); padding:2px 6px; border-radius:4px;">AUTO-GRADER</span>
            </div>
            <div class="card-body" style="padding:0; overflow-x:auto;">
                <table class="gem-table" style="width:100%; text-align:center;">
                    <thead>
                        <tr style="background: rgba(255,255,255,0.03);">
                            <th style="text-align:center;">DATE CIBLE</th>
                            <th style="text-align:center;">ACTIF</th>
                            <th style="text-align:center;">PRÉDICTION (LA VEILLE)</th>
                            <th style="text-align:center;">RÉALITÉ (CLÔTURE)</th>
                            <th style="text-align:center;">PRÉCISION (XGBOOST)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        try {
                            $stmt_ai = $pdo->query("SELECT * FROM ai_predictions WHERE actual_price IS NOT NULL ORDER BY target_date DESC LIMIT 5");
                            $predictions = $stmt_ai->fetchAll(PDO::FETCH_ASSOC);

                            if (count($predictions) > 0) {
                                foreach ($predictions as $row) {
                                    $pred = (float)$row['predicted_price'];
                                    $actual = (float)$row['actual_price'];
                                    
                                    $error_margin = $actual > 0 ? (abs($pred - $actual) / $actual) * 100 : 0;
                                    $accuracy = max(0, 100 - $error_margin);
                                    
                                    if ($accuracy >= 98) $color = 'var(--green)';
                                    elseif ($accuracy >= 95) $color = 'var(--gold)';
                                    else $color = 'var(--red)';
                                    
                                    echo "<tr>";
                                    echo "<td>" . date('d/m/Y', strtotime($row['target_date'])) . "</td>";
                                    echo "<td><b style='color:#fff'>" . htmlspecialchars($row['symbol']) . "</b></td>";
                                    echo "<td style='color: #aaa;'>" . number_format($pred, 2, '.', ' ') . " $</td>";
                                    echo "<td>" . number_format($actual, 2, '.', ' ') . " $</td>";
                                    echo "<td style='color: {$color}; font-weight: bold; font-size:0.8rem;'>" . number_format($accuracy, 2) . " %</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='5' style='padding: 25px; text-align: center; color: #666; font-size: 0.7rem;'>";
                                echo "⏳ INITIALISATION... EN ATTENTE DE LA PREMIÈRE CLÔTURE JOURNALIÈRE POUR NOTER L'IA.";
                                echo "</td></tr>";
                            }
                        } catch (Exception $e) {
                            echo "<tr><td colspan='5' style='padding: 20px; text-align: center; color: var(--red); font-size: 0.7rem;'>";
                            echo "⚠️ LA TABLE 'ai_predictions' DOIT ÊTRE CRÉÉE DANS LA BASE DE DONNÉES.";
                            echo "</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="hud-bar">
        <div id="hud-defcon" class="hud-sec">DEFCON --</div>
        <div class="hud-sec" style="flex:1;"><div style="color:#444; font-size:0.6rem;">TITAN V83_AI /// CORTEX HYBRID ENGINE ENABLED /// ML OPTIMIZATION ACTIVE</div></div>
        <div class="hud-sec" style="background:#111; color:#333; border:none;">SYSTEM_READY</div>
    </div>

    <script>
        let oracleChart = null;
        let winRateChart = null;

        function initCharts() {
            const ctx1 = document.getElementById('oracleChart').getContext('2d');
            Chart.defaults.color = '#666'; Chart.defaults.font.family = 'JetBrains Mono';
            oracleChart = new Chart(ctx1, { 
                type: 'line', 
                data: { 
                    labels: [], 
                    datasets: [
                        { label: 'RÉALITÉ ($)', data: [], borderColor: '#00f3ff', borderWidth: 2, tension: 0.1, pointRadius: 0, fill:true, backgroundColor:'rgba(0,243,255,0.03)' }, 
                        { label: 'ORACLE (Macro)', data: [], borderColor: '#ffc800', borderWidth: 1, borderDash: [5, 5], tension: 0.1, pointRadius: 0 },
                        { label: 'ECHO (Fractal)', data: [], borderColor: '#bd00ff', borderWidth: 1, borderDash: [2, 4], tension: 0.1, pointRadius: 0 },
                        { label: 'TITAN AI (Hybride)', data: [], borderColor: '#ffffff', borderWidth: 3, tension: 0.2, pointRadius: 0, shadowBlur: 10, shadowColor: 'white' }
                    ] 
                }, 
                options: { 
                    responsive: true, maintainAspectRatio: false, 
                    interaction: { mode: 'index', intersect: false }, 
                    scales: { x: { grid: { color: 'rgba(255,255,255,0.02)' } }, y: { grid: { color: 'rgba(255,255,255,0.05)' }, position: 'right' } }, 
                    animation: false 
                } 
            });

            const ctx2 = document.getElementById('winRateChart').getContext('2d');
            winRateChart = new Chart(ctx2, { type: 'line', data: { labels: [], datasets: [{ label: 'Win Rate %', data: [], borderColor: '#00ff9d', backgroundColor: 'rgba(0,255,157,0.1)', borderWidth: 2, fill: true, tension: 0.4, pointRadius: 2 }] }, options: { responsive: true, maintainAspectRatio: false, scales: { x: { display: false }, y: { min: 0, max: 100, ticks: { stepSize: 25, color: '#444', font: { size: 8 } }, grid: { color: '#111' } } }, plugins: { legend: { display: false } }, animation: { duration: 1000 } } });
        }

        async function updateNews() {
            try {
                const res = await fetch('api_news.php');
                const data = await res.json();
                if (data.status === 'ok') {
                    const scroll = document.getElementById('news-scroll');
                    scroll.innerHTML = '';
                    data.news.forEach(item => {
                        const span = document.createElement('span');
                        span.className = 'news-item' + (item.is_alert ? ' alert' : '');
                        span.innerHTML = `[${item.time}] ${item.title}`;
                        scroll.appendChild(span);
                    });
                }
            } catch (e) {}
        }
        
        async function updateOSINTFeed() {
            try {
                const res = await fetch('api_rss.php');
                const data = await res.json();
                const container = document.getElementById('osint-feed');
                if (data.status === 'ok' && data.articles.length > 0) {
                    container.innerHTML = ''; 
                    data.articles.forEach(article => {
                        container.innerHTML += `<div style="border-bottom: 1px solid rgba(255,255,255,0.05); padding: 8px 5px;"><div style="color:var(--gold); font-size:0.55rem; font-weight:bold; margin-bottom:3px;">[${article.date}]</div><a href="${article.link}" target="_blank" style="color:#ccc; text-decoration:none; font-size:0.65rem; display:block; transition:0.2s;" onmouseover="this.style.color='var(--blue)'" onmouseout="this.style.color='#ccc'">${article.title}</a></div>`;
                    });
                } else {
                    container.innerHTML = `<div style="color:var(--red); font-size:0.6rem; text-align:center; margin-top:20px;">[ NO SIGNAL FROM ATLAS FLUX ]</div>`;
                }
            } catch (e) { console.error("OSINT Feed Error", e); }
        }

        async function updatePerformance() {
            try {
                const res = await fetch('api_performance.php');
                const data = await res.json();
                if (data.status === 'ok' && data.winrates.length > 0) {
                    winRateChart.data.labels = data.labels;
                    winRateChart.data.datasets[0].data = data.winrates;
                    winRateChart.update();
                    const lastWR = data.winrates[data.winrates.length - 1];
                    const lastPnL = data.pnls[data.pnls.length - 1];
                    document.getElementById('perf-stats').innerHTML = `<div><span style="color:#666; font-size:0.5rem;">WIN RATE</span><br><b style="color:var(--green); font-size:1.2rem;">${lastWR.toFixed(1)}%</b></div><div><span style="color:#666; font-size:0.5rem;">AVG PnL</span><br><b style="color:#fff; font-size:1.2rem;">${lastPnL > 0 ? '+' : ''}${lastPnL.toFixed(2)}%</b></div>`;
                } else {
                    document.getElementById('perf-stats').innerHTML = `<span style="color:#444; font-size:0.6rem;">WAITING FOR FIRST TRADES...</span>`;
                }
            } catch (e) { console.error("Perf Error", e); }
        }

        async function exportToAI() {
            try {
                const res = await fetch('api_export.php');
                const json = await res.json();
                const text = JSON.stringify(json, null, 4);
                const textArea = document.createElement("textarea");
                textArea.value = text; document.body.appendChild(textArea);
                textArea.select(); document.execCommand('copy');
                document.body.removeChild(textArea);
                const btn = document.getElementById('btn-export');
                btn.innerText = "✅ COPIED!";
                btn.classList.replace('btn-outline-info', 'btn-success');
                setTimeout(() => { btn.innerText = "📋 COPY_JSON"; btn.classList.replace('btn-success', 'btn-outline-info'); }, 2000);
            } catch (err) { alert("Copy failed"); }
        }

        async function copyAssetJSON() {
            const symbol = document.getElementById('pro-asset-select').value;
            const btn = document.getElementById('btn-asset-pro');
            try {
                const res = await fetch(`api_asset.php?symbol=${symbol}`);
                const data = await res.json();
                const text = JSON.stringify(data, null, 4);
                const textArea = document.createElement("textarea");
                textArea.value = text; document.body.appendChild(textArea);
                textArea.select(); document.execCommand('copy');
                document.body.removeChild(textArea);
                const originalText = btn.innerText;
                btn.innerText = "✅ JSON COPIED"; btn.classList.add('copied');
                setTimeout(() => { btn.innerText = originalText; btn.classList.remove('copied'); }, 1500);
            } catch (err) { alert("Error report"); }
        }

        async function refreshChart() {
            const symbol = document.getElementById('pro-asset-select').value;
            const res = await fetch(`api_history.php?symbol=${symbol}&range=1M`);
            const data = await res.json();
            
            if (data.status === 'ok') {
                oracleChart.data.labels = data.labels;
                oracleChart.data.datasets[0].label = `RÉALITÉ (${symbol})`;
                oracleChart.data.datasets[0].data = data.real_data;
                oracleChart.data.datasets[1].data = data.proj_data;
                if(data.echo_data) oracleChart.data.datasets[2].data = data.echo_data;
                
                if(data.ai_data) oracleChart.data.datasets[3].data = data.ai_data;
                
                oracleChart.update();

                // APPEL ASYNCHRONE AU CORTEX PYTHON (XAI)
                document.getElementById('ai-insight').innerText = "CALCUL DES VECTEURS... [XGBOOST]";
                try {
                    const resAI = await fetch(`api_predict.php?symbol=${symbol}`);
                    const dataAI = await resAI.json();
                    
                    if (dataAI.status === 'ok' && dataAI.explanation) {
                        document.getElementById('ai-insight').innerText = dataAI.explanation;
                    } else {
                        document.getElementById('ai-insight').innerText = "[ IA EN COURS D'APPRENTISSAGE OU DÉCONNECTÉE ]";
                    }
                } catch (e) {
                    document.getElementById('ai-insight').innerText = "[ ERREUR DE CONNEXION AU CORTEX PYTHON ]";
                }

                if(data.ai_weights) {
                    const w_oracle = Math.round(data.ai_weights.oracle * 100);
                    const w_echo = Math.round(data.ai_weights.echo * 100);
                    document.getElementById('prob-cen').innerText = w_oracle + "%";
                    document.getElementById('prob-alt').innerText = w_echo + "%";
                }
            }
            
            // ACTUALISATION DES KILL ZONES
            try {
                const resKZ = await fetch(`api_orderbook.php?symbol=${symbol}`);
                const kzData = await resKZ.json();
                if (kzData.status === 'ok') {
                    document.getElementById('kz-up').innerText = kzData.kill_zone_up + " $";
                    document.getElementById('kz-down').innerText = kzData.kill_zone_down + " $";
                    document.getElementById('kz-type').innerText = "[" + kzData.data_source + "]";
                }
            } catch(e) { console.error(e); }

            // 🌟 NOUVEAU : SMART MONEY TRACKER (FINNHUB)
            try {
                document.getElementById('sm-consensus').innerText = "SCANNING...";
                document.getElementById('sm-consensus').style.color = "#fff";
                document.getElementById('sm-data-box').style.display = "none";
                document.getElementById('sm-error-box').style.display = "block";
                document.getElementById('sm-error-box').innerText = "[ CONNEXION À FINNHUB INSTITUTIONAL... ]";

                const resSM = await fetch(`api_smartmoney.php?symbol=${symbol}`);
                const smData = await resSM.json();
                
                if (smData.status === 'ok') {
                    if (smData.supported) {
                        document.getElementById('sm-data-box').style.display = "block";
                        document.getElementById('sm-error-box').style.display = "none";
                        
                        document.getElementById('sm-consensus').innerText = smData.consensus;
                        if(smData.bullish_percent > 50) document.getElementById('sm-consensus').style.color = "var(--green)";
                        else if(smData.bearish_percent > 50) document.getElementById('sm-consensus').style.color = "var(--red)";
                        else document.getElementById('sm-consensus').style.color = "var(--gold)";

                        document.getElementById('sm-bar-bull').style.width = smData.bullish_percent + "%";
                        document.getElementById('sm-bar-bear').style.width = smData.bearish_percent + "%";
                        document.getElementById('sm-val-bull').innerText = smData.bullish_percent + "%";
                        document.getElementById('sm-val-bear').innerText = smData.bearish_percent + "%";
                        document.getElementById('sm-analysts').innerText = smData.analysts_count;
                    } else {
                        document.getElementById('sm-consensus').innerText = "HORS PÉRIMÈTRE";
                        document.getElementById('sm-error-box').innerText = "[ " + smData.msg + " ]";
                    }
                }
            } catch(e) { 
                document.getElementById('sm-consensus').innerText = "ERREUR API";
                document.getElementById('sm-error-box').innerText = "[ ÉCHEC DE COMMUNICATION ]";
            }

            // CORRELATION & GEM
            try {
                const resAsset = await fetch(`api_asset.php?symbol=${symbol}`);
                const dataAsset = await resAsset.json();
                
                if(dataAsset.status === 'ok' || dataAsset.gem_matrix) {
                    if(dataAsset.heartbeat) {
                        const led = document.getElementById('data-heartbeat');
                        led.className = 'status-led led-' + dataAsset.heartbeat.status.toLowerCase();
                        document.getElementById('data-age').innerText = dataAsset.heartbeat.age_minutes + " MIN";
                        const agePercent = Math.min(100, (dataAsset.heartbeat.age_minutes / 60) * 100);
                        document.getElementById('bar-age').style.width = agePercent + "%";
                        document.getElementById('bar-age').style.background = dataAsset.heartbeat.status === 'HEALTHY' ? 'var(--green)' : 'var(--red)';
                    }
                    if(dataAsset.correlation_analysis) {
                        const coeff = dataAsset.correlation_analysis.coefficient;
                        const corrEl = document.getElementById('corr-coeff');
                        corrEl.innerText = (coeff > 0 ? '+' : '') + coeff;
                        corrEl.style.color = Math.abs(coeff) > 0.7 ? 'var(--green)' : '#fff';
                        document.getElementById('corr-desc').innerText = dataAsset.correlation_analysis.description;
                    }
                    if(dataAsset.gem_matrix) {
                        document.getElementById('gem-reading').innerText = dataAsset.gem_matrix.Lecture;
                        const svf = dataAsset.gem_matrix.SVF_Vectoriel_Flux;
                        document.getElementById('gem-svf').innerText = (svf > 0 ? '+' : '') + svf;
                        document.getElementById('gem-svf').style.color = svf > 0 ? 'var(--green)' : (svf < 0 ? 'var(--red)' : '#fff');
                        document.getElementById('gem-sr').innerText = dataAsset.gem_matrix.SR_Robustesse + "/5";
                        document.getElementById('gem-str').innerText = dataAsset.gem_matrix.STR_Tension + "/5";
                    }
                }
            } catch(e) { console.log(e); }

            // CHARGEMENT DU BRIEFING LLM SÉCURISÉ
            const llmBox = document.getElementById('llm-report-box');
            if (llmBox) {
                llmBox.innerHTML = '<span style="color:#666;">[ ACCÈS AUX ARCHIVES... ]</span>';
                try {
                    const cacheBuster = new Date().toISOString().split('T')[0];
                    const resLLM = await fetch(`briefing_${symbol}.html?v=${cacheBuster}`);
                    if (resLLM.ok) {
                        const textHTML = await resLLM.text();
                        llmBox.innerHTML = textHTML;
                    } else {
                        llmBox.innerHTML = `<span style="color:var(--gold);">[ AVIS : Le briefing tactique pour ${symbol} n'a pas encore été généré cette nuit. ]</span>`;
                    }
                } catch (err) {
                    llmBox.innerHTML = `<span style="color:var(--red);">[ ÉCHEC DE CONNEXION AUX ARCHIVES TACTIQUES ]</span>`;
                }
            }
        }

        async function refreshData() {
            try {
                const res = await fetch('api_export.php');
                const data = await res.json();
                const stress = data.matrix.stress_score || data.matrix.stress;
                document.getElementById('stress-display').innerText = stress + "%";
                document.getElementById('directive-display').innerText = data.policy.directive;
                const colors = { 'RED': 'var(--red)', 'GOLD': 'var(--gold)', 'GREEN': 'var(--green)', 'BLUE': 'var(--blue)' };
                const activeColor = colors[data.policy.color] || 'var(--blue)';
                document.getElementById('stress-display').style.color = activeColor;
                document.getElementById('directive-display').style.color = activeColor;
                if (data.policy.color == 'RED' || (data.audit_logic && data.audit_logic.vix_accel_engaged)) {
                    document.getElementById('shield-card').classList.add('pulse-critical');
                } else {
                    document.getElementById('shield-card').classList.remove('pulse-critical');
                }
                const defcon = stress > 80 ? 1 : (stress > 60 ? 2 : (stress > 40 ? 3 : 5));
                const hudD = document.getElementById('hud-defcon');
                hudD.innerText = "DEFCON " + defcon;
                hudD.className = "hud-sec" + (defcon <= 2 ? " defcon-active" : "");
                
                // RÉGIME MACRO-ÉCONOMIQUE
                try {
                    const resMacro = await fetch('api_macro.php');
                    const macroData = await resMacro.json();
                    if (macroData.status === 'ok') {
                        const mColors = { 'RED': 'var(--red)', 'GOLD': 'var(--gold)', 'GREEN': 'var(--green)' };
                        const mColor = mColors[macroData.color] || '#fff';
                        
                        document.getElementById('macro-regime').innerText = macroData.regime;
                        document.getElementById('macro-regime').style.color = mColor;
                        document.getElementById('macro-desc').innerText = macroData.description;
                        
                        const dxySign = macroData.dxy_trend > 0 ? '+' : '';
                        const us10ySign = macroData.us10y_trend > 0 ? '+' : '';
                        
                        document.getElementById('macro-dxy').innerHTML = `DXY: <span style="color:${macroData.dxy_trend > 0 ? 'var(--red)' : 'var(--green)'}">${dxySign}${macroData.dxy_trend}%</span>`;
                        document.getElementById('macro-us10y').innerHTML = `US10Y: <span style="color:${macroData.us10y_trend > 0 ? 'var(--red)' : 'var(--green)'}">${us10ySign}${macroData.us10y_trend}%</span>`;
                    }
                } catch (em) { console.error("Macro Fetch Error", em); }

                refreshChart();
                updatePerformance();
            } catch (e) { console.error("Refresh Error", e); }
        }

        document.addEventListener("DOMContentLoaded", function() {
            initCharts();
            refreshData();
            updateNews();
            updateOSINTFeed(); 
            setInterval(refreshData, 300000); 
            setInterval(updateNews, 60000); 
            setInterval(updateOSINTFeed, 300000); 
        });
    </script>
</body>
</html>