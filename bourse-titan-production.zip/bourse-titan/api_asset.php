<?php
// api_asset.php - V6 "INTELLIGENCE + CORRELATION + HEARTBEAT + KILL ZONES"
// Calcule les métriques GEM, l'Echo Fractal, la corrélation, et scanne le Carnet d'Ordres.

header('Content-Type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
require_once 'db.php';

$symbol = isset($_GET['symbol']) ? strtoupper(trim($_GET['symbol'])) : 'SPY';

// --- FONCTION DE CORRÉLATION DE PEARSON ---
function getCorrelation($x, $y) {
    $n = count($x);
    if ($n !== count($y) || $n === 0) return 0;
    $meanX = array_sum($x) / $n;
    $meanY = array_sum($y) / $n;
    $num = 0; $denX = 0; $denY = 0;
    for ($i = 0; $i < $n; $i++) {
        $dX = $x[$i] - $meanX;
        $dY = $y[$i] - $meanY;
        $num += ($dX * $dY);
        $denX += ($dX * $dX);
        $denY += ($dY * $dY);
    }
    return ($denX * $denY == 0) ? 0 : $num / sqrt($denX * $denY);
}

try {
    // 1. DATA BRUTE & HEARTBEAT (Santé des données)
    $stmt = $pdo->prepare("SELECT created_at FROM market_history WHERE symbol = ? ORDER BY created_at DESC LIMIT 1");
    $stmt->execute([$symbol]);
    $last_update = $stmt->fetchColumn();
    $minutes_ago = $last_update ? round((time() - strtotime($last_update)) / 60) : 999;
    
    $heartbeat_status = ($minutes_ago < 20) ? 'HEALTHY' : (($minutes_ago < 60) ? 'WARNING' : 'STALE');

    $stmt = $pdo->query("SELECT global_stress FROM titan_history ORDER BY id DESC LIMIT 1");
    $global_stress = (int)$stmt->fetchColumn();
    if (!$global_stress) $global_stress = 50;

    $stmt = $pdo->prepare("SELECT * FROM market_data WHERE symbol = ?");
    $stmt->execute([$symbol]);
    $asset = $stmt->fetch(PDO::FETCH_ASSOC);

    // 2. HISTORIQUE & ECHO FRACTAL
    $echoStmt = $pdo->prepare("SELECT price, created_at FROM market_history WHERE symbol = ? ORDER BY created_at ASC LIMIT 1000");
    $echoStmt->execute([$symbol]);
    $full_history = $echoStmt->fetchAll(PDO::FETCH_ASSOC);
    $valid_prices = array_column($full_history, 'price');
    
    $pattern_size = 5; 
    $forecast_horizon = 5; 
    $pct_change = 0;
    $similarity_score = 0;

    if (count($valid_prices) > ($pattern_size * 2) + $forecast_horizon) {
        $current_shape = array_slice($valid_prices, -$pattern_size);
        $base_curr = $current_shape[0] ?: 1;
        $norm_curr = array_map(function($p) use ($base_curr) { return $p / $base_curr; }, $current_shape);

        $best_dist = INF; $best_idx = -1;
        $limit = count($valid_prices) - $pattern_size - $forecast_horizon;
        
        for ($i = 0; $i < $limit; $i++) {
            $window = array_slice($valid_prices, $i, $pattern_size);
            $base_win = $window[0];
            if ($base_win == 0) continue;
            $norm_win = array_map(function($p) use ($base_win) { return $p / $base_win; }, $window);
            $dist = 0;
            for ($j=0; $j<$pattern_size; $j++) $dist += pow($norm_curr[$j] - $norm_win[$j], 2);
            if ($dist < $best_dist) { $best_dist = $dist; $best_idx = $i; }
        }

        $pivot_historical = $valid_prices[$best_idx + $pattern_size - 1];
        $future_ref = $valid_prices[$best_idx + $pattern_size - 1 + $forecast_horizon];
        if ($pivot_historical != 0) $pct_change = ($future_ref - $pivot_historical) / $pivot_historical;
        $similarity_score = max(0, 100 - ($best_dist * 1000));
    }

    // 3. ANALYSE DE CORRÉLATION CROSS-ASSET (vs SPY)
    $correlation = 1.0;
    $corr_desc = "Self-Benchmark";
    if ($symbol !== 'SPY') {
        $stmtC = $pdo->prepare("SELECT price, created_at, symbol FROM market_history 
                               WHERE (symbol = ? OR symbol = 'SPY') 
                               AND created_at > NOW() - INTERVAL 40 DAY ORDER BY created_at ASC");
        $stmtC->execute([$symbol]);
        $rows = $stmtC->fetchAll(PDO::FETCH_ASSOC);

        $dataX = []; $dataY = [];
        foreach ($rows as $r) {
            $day = date('Y-m-d', strtotime($r['created_at']));
            if ($r['symbol'] === $symbol) $dataX[$day] = (float)$r['price'];
            if ($r['symbol'] === 'SPY') $dataY[$day] = (float)$r['price'];
        }
        
        $common_days = array_intersect_key($dataX, $dataY);
        $returnsX = []; $returnsY = []; $pX = null; $pY = null;
        foreach ($common_days as $day => $val) {
            if ($pX && $pY) {
                $returnsX[] = ($val - $pX) / $pX;
                $returnsY[] = ($dataY[$day] - $pY) / $pY;
            }
            $pX = $val; $pY = $dataY[$day];
        }
        $correlation = round(getCorrelation($returnsX, $returnsY), 2);
        $corr_desc = ($correlation > 0.7) ? 'Couplage Fort' : (($correlation < -0.7) ? 'Inversion' : 'Découplage');
    }

    // 4. MOTEUR GEM
    $Pn = round((50 - $global_stress) / 10, 1);
    $Pn = max(-5, min(5, $Pn));

    $change_24h = (float)$asset['change_percent'];
    $Af = round($change_24h * 1.5, 1);
    $Af = max(-5, min(5, $Af));

    $Ff = round($pct_change * 100 * 2, 1);
    $Ff = max(-5, min(5, $Ff));

    $SVF = round($Pn + $Af + $Ff, 1);
    $signs = [ ($Pn >= 0 ? 1 : -1), ($Af >= 0 ? 1 : -1), ($Ff >= 0 ? 1 : -1) ];
    $confluence_score = abs(array_sum($signs));

    $SR = round(($confluence_score / 3) * 5, 1); 
    $STR = round($global_stress / 20, 1);
    if ($confluence_score == 1) $STR += 1;
    $STR = max(0, min(5, $STR));

    $gem_reading = "INCERTAIN (Régime Mixte)";
    if ($SVF > 5 && $SR >= 3) $gem_reading = "MOMENTUM HAUSSIER SAIN";
    elseif ($SVF > 5 && $SR < 3) $gem_reading = "HAUSSE FRAGILE (Divergence)";
    elseif ($SVF < -5 && $STR >= 3) $gem_reading = "RUPTURE BAISSIÈRE (Stress Élevé)";
    elseif ($SVF < -5 && $STR < 3) $gem_reading = "CONSOLIDATION BAISSIÈRE";

    // =====================================================================
    // 🌟 NOUVEAU : RÉCUPÉRATION DES KILL ZONES POUR L'IA (ÉTAPE 9 PRUNCKUN)
    // =====================================================================
    $kz_up = "Inconnu";
    $kz_down = "Inconnu";
    $kz_source = "Inconnu";
    
    // On appelle notre nouveau scanner localement
    $kz_url = "https://" . $_SERVER['HTTP_HOST'] . "/bourse-titan/api_orderbook.php?symbol=" . $symbol;
    $ch_kz = curl_init($kz_url);
    curl_setopt($ch_kz, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch_kz, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch_kz, CURLOPT_TIMEOUT, 3);
    $kz_response = curl_exec($ch_kz);
    curl_close($ch_kz);

    if ($kz_response) {
        $kz_data = json_decode($kz_response, true);
        if (isset($kz_data['status']) && $kz_data['status'] == 'ok') {
            $kz_up = $kz_data['kill_zone_up'];
            $kz_down = $kz_data['kill_zone_down'];
            $kz_source = $kz_data['data_source'];
        }
    }
    // =====================================================================

    // 5. GÉNÉRATION DU JSON COMPLET
    echo json_encode([
        'meta' => [
            'engine' => 'TITAN_GEM_V6',
            'symbol' => $symbol,
            'timestamp' => date('Y-m-d H:i:s')
        ],
        'heartbeat' => [
            'last_sync' => $last_update,
            'age_minutes' => $minutes_ago,
            'status' => $heartbeat_status
        ],
        'correlation_analysis' => [
            'benchmark' => 'SPY',
            'coefficient' => $correlation,
            'description' => $corr_desc
        ],
        'market_data' => [
            'price' => (float)$asset['price'],
            'change_24h' => $change_24h . '%'
        ],
        'gem_matrix' => [
            'Pn_Pression_Narrative' => $Pn,
            'Af_Ancrage_Flux' => $Af,
            'Ff_Force_Fractale' => $Ff,
            'SVF_Vectoriel_Flux' => $SVF,
            'SR_Robustesse' => $SR,
            'STR_Tension' => $STR,
            'Lecture' => $gem_reading
        ],
        'kill_zones' => [
            'resistance_majeure_up' => $kz_up,
            'support_majeur_down' => $kz_down,
            'source_detection' => $kz_source
        ],
        'prunckun_gpt_prompt' => [
            'system_instruction' => "Utilise les données suivantes pour dérouler les 11 étapes de la méthodologie GEM/Prunckun. Formule un rapport stratégique militaire.",
            'etape_1_macro' => "Le stress système est à {$global_stress}%. Pression narrative : {$Pn}/5.",
            'etape_2_flux' => "L'actif {$symbol} est corrélé à {$correlation} avec le SPY ({$corr_desc}). Ancrage Flux : {$Af}/5.",
            'etape_3_signaux_faibles' => "Similarité Echo Fractal : ".round($similarity_score,1)."% | Force fractale : {$Ff}/5.",
            'etape_5_quantitatif' => "SVF: {$SVF}/15 | Robustesse SR: {$SR}/5 | Tension STR: {$STR}/5.",
            'etape_8_scenarios' => "Lecture : '{$gem_reading}'.",
            'etape_9_kill_zones' => "Zone de liquidité haute (Breakout) : {$kz_up}$. Zone basse (Support) : {$kz_down}$."
        ]
    ], JSON_PRETTY_PRINT);

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'msg' => $e->getMessage()]);
}
?>