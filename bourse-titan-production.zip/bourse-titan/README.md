# TITAN V83 AI-CORTEX — Fichiers de production

Contenu minimal nécessaire au fonctionnement de https://visiondufutur.com/bourse-titan/

## Structure

### Pages (frontend)
- `index.php` — Dashboard principal (privé)
- `public.php` — Vue publique
- `backtest.php` — Module de backtest
- `about.php`, `doc.php` — Pages d'information / documentation API

### Cœur
- `db.php` — Connexion PDO MySQL (⚠️ contient les identifiants — voir Sécurité)

### API internes (appelées en AJAX par les pages)
- `api_asset.php` — Données complètes d'un actif (Oracle, Echo, GEM, Kill Zones)
- `api_history.php` — Historique de prix (graphiques)
- `api_orderbook.php` — Carnet d'ordres / Kill Zones
- `api_predict.php` — Pont vers le Cortex Python (api.visiondufutur.com)
- `api_smartmoney.php` — Tracker institutionnel (Finnhub)
- `api_export.php` — Export JSON global (bouton COPY_JSON)
- `api_macro.php` — Régime macro DXY/US10Y
- `api_news.php`, `api_rss.php` — Flux d'actualités
- `api_performance.php` — Win rate / signaux récents
- `api_public.php` — Données de la vue publique

### Tâches planifiées (Cron)
- `fetch_data.php` — Collecteur OHLCV + macro + sentiment (à lancer toutes les 1–5 min)
- `cron_cerebras.php` — Génère les briefings LLM nocturnes + push Telegram (1×/jour, ex: 04h00)
- `train_ai.php` — Réentraînement des poids Oracle/Echo (1×/jour ou 1×/semaine)

### Fichiers générés / cache
- `briefing_SPY.html`, `briefing_QQQ.html`, `briefing_BTCUSDT.html`, `briefing_GOLD.html`, `briefing_VIX.html` — Briefings statiques régénérés par cron_cerebras.php
- `last_update.txt` — Verrou anti-flood de fetch_data.php

## Tables MySQL requises
`market_data`, `market_history`, `titan_history`, `titan_cortex`, `titan_performance`, `ai_predictions`, `alerts`, `titan_winrate_log`

## Dépendance externe
Le module XAI/prédiction repose sur une API Python séparée : `https://api.visiondufutur.com/predict/{symbol}` et `/generate_brief` (non incluse dans ce dossier PHP).

## ⚠️ SÉCURITÉ — À FAIRE IMMÉDIATEMENT
1. Les clés API (Cerebras, Telegram) et le mot de passe MySQL sont en clair dans `cron_cerebras.php` et `db.php`. **Régénérez ces clés** et déplacez-les dans un fichier de config hors racine web (ou variables d'environnement).
2. Supprimez du serveur les scripts de maintenance non inclus ici (`reset.php`, `fix_db.php`, `clean.php`, `debug.php`, `seed_history.php`, `backfill.php`, `import_historical.php`, `test_*.php`) : accessibles publiquement, ils permettent à n'importe qui de vider ou corrompre la base.
3. Protégez `fetch_data.php`, `train_ai.php` et `cron_cerebras.php` par un token secret (`?key=...`) ou une règle .htaccess, sinon un visiteur peut les déclencher.
