<?php
// api_orderbook.php - RAYONS X DU CARNET D'ORDRES (KILL ZONES)
ini_set('display_errors', 0);
header('Content-Type: application/json');
require_once 'db.php';

$symbol = $_GET['symbol'] ?? 'BTCUSDT';

try {
    $support_price = 0;
    $resist_price = 0;
    $type = "NONE";

    if ($symbol === 'BTCUSDT') {
        // 1. Carnet d'ordres réel Binance (Level 2 - 500 niveaux)
        $url = "https://api.binance.com/api/v3/depth?symbol=BTCUSDT&limit=500";
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERAGENT, 'TITAN_ENGINE');
        curl_setopt($ch, CURLOPT_TIMEOUT, 3);
        $response = curl_exec($ch);
        curl_close($ch);

        $data = json_decode($response, true);
        if (isset($data['bids']) && isset($data['asks'])) {
            // Trouver le plus gros mur d'achat (Support de la Baleine)
            $max_bid_vol = 0;
            foreach ($data['bids'] as $bid) {
                $price = (float)$bid[0]; $vol = (float)$bid[1];
                if ($vol > $max_bid_vol) { $max_bid_vol = $vol; $support_price = $price; }
            }

            // Trouver le plus gros mur de vente (Résistance de la Baleine)
            $max_ask_vol = 0;
            foreach ($data['asks'] as $ask) {
                $price = (float)$ask[0]; $vol = (float)$ask[1];
                if ($vol > $max_ask_vol) { $max_ask_vol = $vol; $resist_price = $price; }
            }
            $type = "BINANCE_LEVEL2";
        }
    } else {
        // 2. TradFi (SPY, QQQ) : Calcul des Pivots Institutionnels
        $stmt = $pdo->prepare("SELECT high, low, price as close FROM market_history WHERE symbol = ? ORDER BY created_at DESC LIMIT 1");
        $stmt->execute([$symbol]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            $h = (float)$row['high']; $l = (float)$row['low']; $c = (float)$row['close'];
            $pivot = ($h + $l + $c) / 3;
            // S1 et R1 (Formule standard des Kill Zones intraday)
            $support_price = (2 * $pivot) - $h; 
            $resist_price = (2 * $pivot) - $l;  
            $type = "INSTITUTIONAL_PIVOTS";
        }
    }

    echo json_encode([
        'status' => 'ok',
        'symbol' => $symbol,
        'kill_zone_down' => round($support_price, 2),
        'kill_zone_up' => round($resist_price, 2),
        'data_source' => $type
    ]);

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'msg' => $e->getMessage()]);
}
?>