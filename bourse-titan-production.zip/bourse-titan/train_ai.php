<?php
// train_ai.php - TITAN CORTEX (Machine Learning Engine)
// Algorithme : Grid Search Regression (Optimisation par Force Brute Légère)
ini_set('display_errors', 1);
require_once 'db.php';

echo "<body style='background:#050505; color:#00ff9d; font-family:monospace; padding:20px;'>";
echo "<h1>🧠 TITAN CORTEX : INITIALISATION DE L'APPRENTISSAGE...</h1>";

$assets = ['SPY', 'QQQ', 'BTCUSDT', 'GOLD', 'VIX'];
$assets_config = ['SPY' => 1.0, 'QQQ' => 1.2, 'BTCUSDT' => 1.5, 'GOLD' => -0.4, 'VIX' => -2.0];

// On entraîne l'IA sur les 30 derniers jours fermés
$training_days = 30; 

foreach ($assets as $symbol) {
    echo "<hr><h3>🔄 ANALYSE NEURONALE : $symbol</h3>";
    
    // 1. Récupération de la Donnée d'Entraînement (Training Set)
    // On a besoin de : Prix Réel, et de quoi recalculer Oracle et Echo
    $stmt = $pdo->prepare("SELECT price, created_at FROM market_history WHERE symbol = ? ORDER BY created_at ASC");
    $stmt->execute([$symbol]);
    $history = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $prices = [];
    foreach ($history as $h) { $prices[] = (float)$h['price']; }
    $count = count($prices);
    
    if ($count < $training_days + 10) {
        echo "<span style='color:red'>[SKIP] Pas assez de données.</span><br>";
        continue;
    }

    // On isole la période cible (les 30 derniers jours connus)
    // La "Target" (Y) est ce qui s'est réellement passé.
    $targets = array_slice($prices, -$training_days);
    
    // Pour chaque jour cible, on doit savoir ce que l'Oracle et l'Echo AURAIENT prédit ce jour-là.
    // C'est gourmand en calcul, donc on simplifie : on génère les prédictions basées sur J-30
    // comme si on était il y a un mois.
    
    $start_index = $count - $training_days;
    $start_price = $prices[$start_index - 1]; // Le prix il y a 30 jours
    
    // --- GÉNÉRATION DES FEATURES (X) ---
    
    // A. Feature Echo (Pattern Matching sur la période J-60 à J-30)
    $pattern_size = 5;
    $train_window = array_slice($prices, 0, $start_index); // L'histoire connue il y a 30 jours
    
    // (Algorithme Echo simplifié pour l'entraînement)
    $echo_preds = [];
    // ... Logique de pattern matching rapide ...
    // Pour simplifier l'entraînement, on simule que l'Echo a trouvé le meilleur pattern "moyen"
    // Dans une V2, on remettrait tout l'algo de pattern matching ici.
    // Pour l'instant, on va assumer que l'Echo projette le pattern passé le plus proche.
    
    // Simulation Echo pour l'entraînement (Pattern Matching Rapide)
    $current_shape = array_slice($train_window, -$pattern_size);
    $base = $current_shape[0];
    $norm_curr = array_map(function($p) use ($base){return $p/$base;}, $current_shape);
    
    $best_idx = 0; $min_dist = INF;
    for($i=0; $i < count($train_window)-$pattern_size-$training_days; $i++) {
        $sample = array_slice($train_window, $i, $pattern_size);
        $b = $sample[0]; if($b==0) continue;
        $dist = 0;
        for($k=0; $k<$pattern_size; $k++) $dist += pow(($sample[$k]/$b) - $norm_curr[$k], 2);
        if($dist < $min_dist) { $min_dist = $dist; $best_idx = $i; }
    }
    // Projection Echo
    $pivot = $train_window[$best_idx + $pattern_size - 1];
    for($t=1; $t<=$training_days; $t++) {
        $ref = $train_window[$best_idx + $pattern_size - 1 + $t];
        $chg = ($ref - $pivot) / $pivot;
        $echo_preds[] = $start_price * (1 + $chg);
    }

    // B. Feature Oracle (Mathématique)
    $beta = $assets_config[$symbol];
    $stress = 50; // On assume un stress moyen pour l'entraînement
    $macro_force = (50 - $stress) / 1000;
    $daily_drift = ($macro_force * $beta) / 3; // On simplifie l'inertie pour l'entrainement
    
    $oracle_preds = [];
    $curr = $start_price;
    for($t=1; $t<=$training_days; $t++) {
        $decay = 1 / sqrt($t);
        $move = $daily_drift * $decay; // Oracle PUR (sans bruit) pour trouver la tendance de fond
        $curr = $curr * (1 + $move);
        $oracle_preds[] = $curr;
    }

    // 2. L'OPTIMISATION (GRID SEARCH)
    // On cherche le meilleur mélange : Poids * Echo + (1-Poids) * Oracle
    
    $best_weight_echo = 0.5;
    $lowest_error = INF;
    
    // On teste tous les poids de 0.00 à 1.00 par pas de 0.01
    for ($w = 0; $w <= 100; $w++) {
        $weight = $w / 100; // Poids donné à l'ECHO
        $total_error = 0;
        
        for ($d = 0; $d < $training_days; $d++) {
            if (!isset($targets[$d])) continue;
            
            // La prédiction hybride
            $hybrid = ($echo_preds[$d] * $weight) + ($oracle_preds[$d] * (1 - $weight));
            
            // Calcul de l'erreur au carré (MSE)
            $diff = $targets[$d] - $hybrid;
            $total_error += ($diff * $diff);
        }
        
        if ($total_error < $lowest_error) {
            $lowest_error = $total_error;
            $best_weight_echo = $weight;
        }
    }
    
    $best_weight_oracle = 1 - $best_weight_echo;
    $final_error_percent = sqrt($lowest_error / $training_days) / $start_price * 100; // RMSE en %

    // 3. ENREGISTREMENT DU CERVEAU
    // On sauvegarde ce que l'IA a appris
    $sql = "INSERT INTO titan_cortex (symbol, weight_oracle, weight_echo, error_rate, last_trained, status) 
            VALUES (?, ?, ?, ?, NOW(), 'OPTIMIZED') 
            ON DUPLICATE KEY UPDATE weight_oracle=?, weight_echo=?, error_rate=?, last_trained=NOW(), status='UPDATED'";
    
    $pdo->prepare($sql)->execute([
        $symbol, $best_weight_oracle, $best_weight_echo, $final_error_percent,
        $best_weight_oracle, $best_weight_echo, $final_error_percent
    ]);

    // Rapport
    echo "✅ <b>Apprentissage terminé.</b><br>";
    echo "Scoring : Echo " . ($best_weight_echo*100) . "% | Oracle " . ($best_weight_oracle*100) . "%<br>";
    echo "Marge d'erreur moyenne : " . number_format($final_error_percent, 2) . "%<br>";
    
    // Barres visuelles
    echo "<div style='display:flex; margin-top:5px; width:300px; height:10px; background:#333;'>";
    echo "<div style='width:".($best_weight_oracle*100)."%; background:#ffc800;'></div>"; // Oracle (Jaune)
    echo "<div style='width:".($best_weight_echo*100)."%; background:#bd00ff;'></div>";   // Echo (Violet)
    echo "</div><br>";
}

echo "<br><hr><h1>🏁 SYSTÈME MIS À JOUR</h1>";
?>