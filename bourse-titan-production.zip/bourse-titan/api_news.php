<?php
// api_news.php - V63.1 "THE STEALTH WIRE"
header('Content-Type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");

// Flux direct CNBC Business (Plus fiable)
$rss_url = "https://www.cnbc.com/id/10001147/device/rss/rss.html";

function get_rss_content($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    // On se fait passer pour un navigateur pour éviter d'être bloqué
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/91.0.4472.124 Safari/537.36');
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
}

try {
    $rss_content = get_rss_content($rss_url);
    
    if (!$rss_content) {
        throw new Exception("Impossible de récupérer le flux");
    }

    libxml_use_internal_errors(true);
    $xml = simplexml_load_string($rss_content);
    
    $news = [];
    if ($xml && isset($xml->channel->item)) {
        foreach ($xml->channel->item as $item) {
            $title = (string)$item->title;
            
            // DÉTECTION D'URGENCE (Keywords)
            $is_alert = false;
            $critical_words = ['CRASH', 'WAR', 'FED', 'RECESSION', 'COLLAPSE', 'BREAKING', 'DRAGS', 'DOWN', 'FALLS'];
            foreach($critical_words as $word) {
                if (stripos($title, $word) !== false) {
                    $is_alert = true;
                    break;
                }
            }

            $news[] = [
                'title' => strtoupper($title),
                'time' => date('H:i', strtotime((string)$item->pubDate)),
                'is_alert' => $is_alert
            ];
            if (count($news) >= 8) break; // Un peu plus de titres pour le défilement
        }
    }

    echo json_encode([
        'status' => 'ok',
        'news' => $news
    ]);

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'news' => [], 'msg' => $e->getMessage()]);
}
?>