<?php
// cron_cerebras.php - GÉNÉRATEUR NOCTURNE DE RAPPORTS TITAN + TELEGRAM PUSH (MULTI-CIBLES)
// A configurer en tâche Cron 1 fois par jour (ex: 04h00)

ini_set('display_errors', 1);
error_reporting(E_ALL);

// ⚠️ VOS CLÉS D'API
$api_key = "csk-xjcftekyjwv25c23wm2596cx2fexeddhjjcwfwdjvpn8pxv3"; 
$telegram_bot_token = "8765274537:AAHaCOtXZGytYP5xGGveg9PpXp-1-FPtNU0"; 

// 👥 LISTE DES COMMANDANTS (Vous + Votre collègue)
$telegram_chat_ids = [
    "2142502994", // Vous
    "994877876"   // Collègue
];

$assets = ['SPY', 'QQQ', 'BTCUSDT', 'GOLD', 'VIX'];

// Préparation du message Telegram de résumé
$telegram_message = "🟢 *TITAN CORTEX - RAPPORTS NOCTURNES*\n_Générés le " . date('d/m/Y à H:i') . "_\n\n";
$global_stress_detected = "Inconnu";

echo "<h3>⚔️ INITIATION DU PROTOCOLE CEREBRAS...</h3>";

foreach ($assets as $symbol) {
    echo "Génération du rapport pour $symbol... ";
    
    // 1. On récupère la photographie du marché
    $asset_url = "https://visiondufutur.com/bourse-titan/api_asset.php?symbol=" . $symbol;
    
    // On utilise cURL
    $ch_local = curl_init($asset_url);
    curl_setopt($ch_local, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch_local, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch_local, CURLOPT_TIMEOUT, 15);
    $market_data = curl_exec($ch_local);
    curl_close($ch_local);

    // Extraction des données pour le résumé Telegram
    if ($market_data) {
        $json_data = json_decode($market_data, true);
        if (isset($json_data['market_data']['price'])) {
            $price = $json_data['market_data']['price'];
            $reading = $json_data['gem_matrix']['Lecture'] ?? 'Neutre';
            $kz_up = $json_data['kill_zones']['resistance_majeure_up'] ?? '--';
            $kz_down = $json_data['kill_zones']['support_majeur_down'] ?? '--';
            
            // On capture le stress global via le SPY
            if ($symbol == 'SPY' && isset($json_data['prunckun_gpt_prompt']['etape_1_macro'])) {
                preg_match('/stress système est à (\d+)%/', $json_data['prunckun_gpt_prompt']['etape_1_macro'], $matches);
                if (isset($matches[1])) $global_stress_detected = $matches[1] . "%";
            }

            // On ajoute la ligne au rapport Telegram
            $telegram_message .= "🔹 *$symbol* : $price $\n";
            $telegram_message .= "└ GEM : _{$reading}_\n";
            $telegram_message .= "└ KZ  : $kz_down$ ⬇️ | $kz_up$ ⬆️\n\n";
        }
    }

    // 2. Le Prompt pour Cerebras
    $system_prompt = "Tu es TITAN, un système expert en Renseignement Financier Quantitatif et Stratégie de Guerre Asymétrique. 
Tu fusionnes la méthodologie de Hank Prunckun, la Boucle OODA et la logique probabiliste Bayésienne.
Ton rôle est d'ingérer les données JSON et de produire un 'Targeting Brief' clinique, militaire et mathématique.
Génère ce rapport exact avec les balises de formatage :

### 🎯 BRIEFING DE RENSEIGNEMENT TACTIQUE [TITAN]
**ACTIF :** [Nom] | **COTE :** [Prix] | **HORODATAGE :** [Date]

**PHASE I : CARTOGRAPHIE DU CHAMP DE BATAILLE**
* **1. Théâtre Macro (Gravité) :**
* **2. Loi de Lanchester (Rapport de Force) :**
* **3. Brouillard de Guerre (Friction) :**

**PHASE II : ÉVALUATION STRATÉGIQUE**
* **4. Matrice GEM :**
* **5. Centre de Gravité :**
* **6. Analyse Bayésienne :**

**PHASE III : PLANIFICATION TACTIQUE**
* **7. Projection des Scénarios :**
* **8. Red Teaming :**
* **9. Kill Zones :**
* **10. DIRECTIVE OPÉRATIONNELLE :**";

    $post_data = [
        "model" => "llama3.1-8b",
        "messages" => [
            ["role" => "system", "content" => $system_prompt],
            ["role" => "user", "content" => "Voici les données du marché à analyser : " . $market_data]
        ],
        "temperature" => 0.2,
        "max_completion_tokens" => 1500,
        "stream" => false
    ];

    // 3. Appel à Cerebras
    $ch = curl_init("https://api.cerebras.ai/v1/chat/completions");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Content-Type: application/json",
        "Authorization: Bearer " . $api_key
    ]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30); 

    $response = curl_exec($ch);
    curl_close($ch);

    $res_json = json_decode($response, true);
    
    // 4. Traitement et Sauvegarde
    if (isset($res_json['choices'][0]['message']['content'])) {
        $report = $res_json['choices'][0]['message']['content'];

        // Mise en forme Cyber/HTML
        $formatted = preg_replace('/\\*\\*(.*?)\\*\\*/', '<b style="color:var(--gold)">$1</b>', $report);
        $formatted = preg_replace('/### (.*?)\\n/', '<br><h3 style="color:var(--blue); margin-bottom:5px; margin-top:15px; border-bottom:1px solid #333; padding-bottom:5px;">$1</h3>', $formatted);
        $formatted = preg_replace('/\\* (.*?):/', '<br><span style="color:var(--white)">■ $1:</span>', $formatted);

        // On sauvegarde le résultat dans un simple fichier HTML
        file_put_contents(__DIR__ . "/briefing_{$symbol}.html", $formatted);
        echo "<b style='color:green'>[ OK ]</b><br>";
    } else {
        echo "<b style='color:red'>[ ÉCHEC DE L'IA ]</b><br>";
    }
    
    // Pause pour ne pas spammer l'API Cerebras
    sleep(2);
}

// =====================================================================
// 📱 5. EXPÉDITION DU RÉSUMÉ SUR TELEGRAM (EN BOUCLE POUR L'ÉQUIPE)
// =====================================================================
$telegram_message .= "⚠️ *STRESS SYSTÈME (DEFCON)* : $global_stress_detected\n";
$telegram_message .= "\n_Les briefings complets sont disponibles sur le terminal TITAN._";

$tg_url = "https://api.telegram.org/bot" . $telegram_bot_token . "/sendMessage";

foreach ($telegram_chat_ids as $chat_id) {
    $tg_data = [
        'chat_id' => $chat_id,
        'text' => $telegram_message,
        'parse_mode' => 'Markdown'
    ];

    $ch_tg = curl_init($tg_url);
    curl_setopt($ch_tg, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch_tg, CURLOPT_POST, true);
    curl_setopt($ch_tg, CURLOPT_POSTFIELDS, $tg_data);
    curl_setopt($ch_tg, CURLOPT_SSL_VERIFYPEER, false);
    $tg_response = curl_exec($ch_tg);
    curl_close($ch_tg);
}

echo "<h3>✅ CYCLE COMPLET ACHEVÉ. Notifications Telegram envoyées à l'équipe.</h3>";
?>