<?php
// doc.php - DOCUMENTATION OFFICIELLE TITAN V78 PRO (Livre Blanc Complet)
ini_set('display_errors', 0);
date_default_timezone_set('Europe/Paris');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TITAN | Documentation Opérationnelle</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700&family=Rajdhani:wght@600;700&display=swap" rel="stylesheet">
    <style>
        :root { --bg: #020305; --card: rgba(14, 16, 21, 0.96); --brd: 1px solid rgba(255, 255, 255, 0.08); --red: #ff2a6d; --blue: #00f3ff; --green: #00ff9d; --gold: #ffc800; --purple: #bd00ff; }
        body { background: var(--bg); color: #cfcfcf; font-family: 'JetBrains Mono', monospace; font-size: 0.8rem; padding-bottom: 60px; line-height: 1.6; }
        
        .top-bar { padding: 15px 20px; border-bottom: var(--brd); background: rgba(5,5,5,0.98); display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 999; }
        .logo { font-family: 'Rajdhani', sans-serif; font-size: 1.6rem; font-weight: bold; letter-spacing: 2px; color: #fff; text-transform: uppercase; }
        
        .container-doc { max-width: 900px; margin: 40px auto; }
        .cyber-card { background: var(--card); border: var(--brd); border-radius: 4px; margin-bottom: 30px; overflow: hidden; backdrop-filter: blur(15px); }
        .card-header { padding: 15px 20px; font-family: 'Rajdhani', sans-serif; font-weight: 700; border-bottom: var(--brd); background: rgba(255,255,255,0.03); font-size: 1.2rem; letter-spacing: 1px; color: #fff; }
        .card-body { padding: 25px; }
        
        h4 { color: var(--blue); font-family: 'Rajdhani', sans-serif; font-weight: 700; margin-top: 25px; margin-bottom: 15px; text-transform: uppercase; letter-spacing: 1px; border-left: 3px solid var(--blue); padding-left: 10px; }
        p { margin-bottom: 15px; color: #aaa; }
        ul { margin-bottom: 20px; padding-left: 20px; color: #aaa; }
        li { margin-bottom: 8px; }
        
        .badge-quant { padding: 4px 8px; border-radius: 4px; font-size: 0.7rem; font-weight: bold; margin-right: 10px; display: inline-block; min-width: 80px; text-align: center; }
        .bq-blue { background: rgba(0, 243, 255, 0.1); color: var(--blue); border: 1px solid var(--blue); }
        .bq-gold { background: rgba(255, 200, 0, 0.1); color: var(--gold); border: 1px solid var(--gold); }
        .bq-purple { background: rgba(189, 0, 255, 0.1); color: var(--purple); border: 1px solid var(--purple); }
        .bq-green { background: rgba(0, 255, 157, 0.1); color: var(--green); border: 1px solid var(--green); }
        .bq-red { background: rgba(255, 42, 109, 0.1); color: var(--red); border: 1px solid var(--red); }

        .code-block { background: #000; border: 1px solid #333; padding: 15px; border-radius: 4px; font-family: 'JetBrains Mono', monospace; font-size: 0.7rem; color: #00ff9d; overflow-x: auto; white-space: pre-wrap; }
        .prompt-block { background: #0a0a0a; border: 1px solid var(--purple); color: #e2e8f0; }
        
        .terminal-btn { color: #fff; text-decoration: none; border: 1px solid #333; padding: 6px 15px; border-radius: 4px; transition: 0.2s; font-size: 0.7rem; }
        .terminal-btn:hover { background: #fff; color: #000; }
        
        .cheat-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        .cheat-table th { color: var(--gold); text-align: left; padding: 10px; border-bottom: 1px solid #333; font-family: 'Rajdhani', sans-serif; font-size: 0.9rem; }
        .cheat-table td { padding: 10px; border-bottom: 1px solid #111; color: #ccc; }
    </style>
</head>
<body>

    <div class="top-bar">
        <div class="logo">TITAN <span style="color:var(--gold)">DOCS</span></div>
        <div>
            <a href="index.php" class="terminal-btn">⬅ RETOUR AU TERMINAL</a>
        </div>
    </div>

    <div class="container-doc">
        
        <div class="text-center mb-5 mt-4">
            <h1 style="font-family:'Rajdhani', sans-serif; font-weight:800; color:#fff; font-size:3rem; letter-spacing:2px;">MANUEL OPÉRATIONNEL</h1>
            <p style="font-size:1rem; color:var(--blue);">Architecture Quantitative & Modèle GEM/Prunckun (V78)</p>
        </div>

        <div class="cyber-card">
            <div class="card-header">1. VUE D'ENSEMBLE DU SYSTÈME</div>
            <div class="card-body">
                <p><strong>TITAN</strong> n'est pas un simple agrégateur de prix. C'est un moteur d'intelligence financière conçu pour filtrer le "bruit" du marché et exposer les véritables dynamiques sous-jacentes (Liquidité, Stress, Historique Fractal).</p>
                <p>Le système opère sur un <strong>horizon de Swing Trading (1 Mois)</strong>. Il combine une analyse macro-économique classique avec une modélisation comportementale complexe basée sur la méthode du Renseignement Financier (Modèle GEM de Prunckun).</p>
            </div>
        </div>

        <div class="cyber-card">
            <div class="card-header">2. LE GRAPHIQUE ORACLE & ECHO</div>
            <div class="card-body">
                <p>Le graphique central projette l'avenir sur 30 jours en confrontant deux mathématiques distinctes :</p>
                <ul>
                    <li><span class="badge-quant bq-blue">RÉALITÉ</span> <strong>Courbe bleue :</strong> L'historique exact des 30 derniers jours (1 point = 1 fermeture journalière).</li>
                    <li><span class="badge-quant bq-gold">ORACLE</span> <strong>Courbe jaune :</strong> La prédiction "Macro". Applique l'inertie du prix et le Stress Global du marché. Si le stress est bas, l'Oracle projette une hausse lisse. S'il monte, l'Oracle s'aplatit ou chute.</li>
                    <li><span class="badge-quant bq-purple">ECHO</span> <strong>Courbe violette :</strong> La prédiction "Fractale" (Pattern Matching). Scanne le passé pour trouver le motif mathématique le plus similaire, puis calque son dénouement historique sur le futur.</li>
                </ul>
                <p><em>👉 <strong>Règle d'Or :</strong> La Confluence. Si la courbe Jaune (Macro) et la courbe Violette (Histoire) pointent dans la même direction, la probabilité du mouvement est maximale.</em></p>
            </div>
        </div>

        <div class="cyber-card">
            <div class="card-header">3. LEXIQUE QUANTITATIF (CHEAT SHEET)</div>
            <div class="card-body">
                <p>Pour lire la Matrice GEM d'un simple coup d'œil, voici l'échelle des valeurs générées par l'algorithme :</p>
                
                <table class="cheat-table">
                    <tr>
                        <th style="width:20%">Métrique</th>
                        <th style="width:20%">Min / Max</th>
                        <th style="width:60%">Interprétation</th>
                    </tr>
                    <tr>
                        <td><strong>SVF</strong><br><span style="font-size:0.6rem; color:#888;">(Vecteur Flux)</span></td>
                        <td><span style="color:var(--red)">-15</span> à <span style="color:var(--green)">+15</span></td>
                        <td>Addition de la Narrative, de l'Ancrage et de la Force Fractale. Un score positif (>5) indique un marché acheteur sain. Un score négatif (<-5) signale un danger.</td>
                    </tr>
                    <tr>
                        <td><strong>SR</strong><br><span style="font-size:0.6rem; color:#888;">(Robustesse)</span></td>
                        <td><span style="color:var(--red)">0</span> à <span style="color:var(--green)">5</span></td>
                        <td>Mesure la Confluence. Si tous les capteurs disent la même chose, SR approche de 5. S'ils se contredisent, le SR chute vers 1 ou 2 (Marché piégeux/incertain).</td>
                    </tr>
                    <tr>
                        <td><strong>STR</strong><br><span style="font-size:0.6rem; color:#888;">(Tension)</span></td>
                        <td><span style="color:var(--green)">0</span> à <span style="color:var(--red)">5</span></td>
                        <td>Risque de rupture (Tail Risk). Si le STR dépasse 3.5, un mouvement violent est imminent. S'il est bas (< 2), la tendance se poursuivra tranquillement.</td>
                    </tr>
                    <tr>
                        <td><strong>VETO VIX</strong><br><span style="font-size:0.6rem; color:#888;">(Bouclier)</span></td>
                        <td>Seuil : <strong>18</strong></td>
                        <td>Si les volumes s'emballent mais que le VIX reste sous 18, le Veto s'active et bloque le "Stress Score" à 40 max, empêchant TITAN de déclencher de faux signaux de Krach.</td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="cyber-card">
            <div class="card-header">4. EXPORT JSON & IA (PRUNCKUN GPT)</div>
            <div class="card-body">
                <p>TITAN agit comme le capteur (les yeux) d'une Intelligence Artificielle qui jouera le rôle d'Analyste (le cerveau).</p>
                <ul>
                    <li><strong>[ COPY_JSON ] (Haut) :</strong> Copie l'état Macro Global. C'est un JSON "Audit-Proof" qui montre l'exactitude mathématique de l'agrégation du stress (Cascade d'arbitrage, drivers primaires).</li>
                    <li><strong>[ EXPORT GPT_PROMPT ] (Graphique) :</strong> C'est l'arme absolue. Copie un bloc contenant la Matrice GEM calculée, prêt à être collé dans le "GPT Prunckun" pour lancer l'analyse en 11 étapes.</li>
                </ul>

                <h4>Le Cerveau de l'IA (Sauvegarde du Prompt Système)</h4>
                <p>Si vous devez recréer votre <em>Custom GPT</em>, voici le prompt système original et inaltéré qu'il faut coller dans ses "Instructions" :</p>
                
                <div class="code-block prompt-block">Tu es l'Analyste Stratégique "TITAN", un expert en Renseignement Financier Quantitatif utilisant la méthodologie de Hank Prunckun appliquée aux marchés (Modèle GEM). 

Ton rôle exclusif est de réceptionner les données JSON fournies par le terminal "TITAN V78" et de rédiger un rapport d'Intelligence Économique complet en suivant rigoureusement un protocole en 11 étapes. Dès que l'utilisateur te colle un bloc JSON "prunckun_gpt_prompt", génère un rapport structuré ainsi :

### 🛡️ RAPPORT DE RENSEIGNEMENT TITAN (PROTOCOLE PRUNCKUN)
[Indique ici l'actif, son prix et la date du système]

**PHASE I : COLLECTE & CONTEXTUALISATION**
* **Étape 1 - Cadrage Macro :** Analyse le Stress et la Pression Narrative (Pn). Définis le sentiment de fond.
* **Étape 2 - Dynamique des Flux :** Analyse l'évolution 24h et l'Ancrage Flux (Af).
* **Étape 3 - Signaux Faibles :** Analyse la Force Fractale (Ff) issue du modèle Echo.

**PHASE II : ÉVALUATION QUANTITATIVE**
* **Étape 4 - Évaluation de la Menace :** Analyse la Tension (STR). Risque de rupture (Tail Risk) ?
* **Étape 5 - Matrice GEM :** Analyse le Score Vectoriel des Flux (SVF).
* **Étape 6 - Hypothèses Intiales :** Formule 2 hypothèses de travail sur le marché.
* **Étape 7 - Test de Validité :** Utilise la Robustesse (SR). Réfute une des hypothèses si la robustesse (confluence) est faible.

**PHASE III : PROJECTION & INTELLIGENCE**
* **Étape 8 - Génération des Scénarios :** (Central, Alternatif fractal, Rupture).
* **Étape 9 - Matrice de Risque :** Probabilité vs Impact des scénarios.
* **Étape 10 - CIRs (Critical Intelligence Requirements) :** Quels sont les niveaux de prix clés (pivots) à surveiller dans les 48h ?
* **Étape 11 - RECOMMANDATION FINALE :** Verdict clair et "Actionable" (ex: Couverture, Accumulation, Liquidation tactique).

Règles : Ton ton doit être clinique, froid et objectif (style hedge fund). Ne donne jamais de conseils financiers légaux.</div>
            </div>
        </div>

        <div class="cyber-card">
            <div class="card-header">5. ARCHITECTURE TECHNIQUE (MAINTENANCE)</div>
            <div class="card-body">
                <p>TITAN est conçu pour fonctionner de manière 100% autonome sur votre serveur. Voici comment le flux de données vit sous le capot :</p>
                <ul>
                    <li><strong>Mise à jour des prix :</strong> Gérée par une tâche <code>CRON</code> externe qui appelle un script (ex: <code>fetch_data.php</code> ou <code>binance.php</code>) à intervalles réguliers pour alimenter la base de données <code>market_history</code>.</li>
                    <li><strong>Calcul à la volée :</strong> Rien n'est pré-calculé ou figé. Quand vous ouvrez l'interface, <code>api_history.php</code>, <code>api_export.php</code> et <code>api_asset.php</code> lisent la base de données brute, agrègent les points journaliers (Daily Close), et calculent les scores (Momentum, Stress, Echo Fractal) instantanément.</li>
                    <li><strong>Prérequis Base de données :</strong> L'algorithme de <em>Pattern Matching</em> (Echo) nécessite au minimum 60 jours d'historique de prix dans la base de données pour pouvoir trouver des correspondances mathématiques viables. En deçà, l'algorithme tirera une ligne de projection droite (neutre).</li>
                </ul>
            </div>
        </div>

        <div class="text-center mt-5 mb-5">
            <p style="font-size: 0.7rem; color: #555;">TITAN QUANTITATIVE SYSTEMS V78 © 2026<br>
            Les informations fournies par ce terminal sont des modèles mathématiques probabilistes et ne constituent pas un conseil en investissement.</p>
        </div>

    </div>

</body>
</html>