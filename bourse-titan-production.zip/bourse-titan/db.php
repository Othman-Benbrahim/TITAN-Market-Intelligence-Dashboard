<?php
// db.php - Connexion à la base de données

// --- CONFIGURATION INFINITY FREE ---
$host = 'mysql-othman.alwaysdata.net';     // Remplacer par "MySQL Hostname" du panneau
$db   = 'othman_titan'; // Remplacer par "Database Name" (souvent avec un préfixe)
$user = 'othman';           // Remplacer par "MySQL Username"
$pass = 'Kf6.nLi,B8#$d3Z'; // Votre mot de passe (le même que pour se connecter au panel/FTP)

$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
    PDO::ATTR_TIMEOUT            => 10, // Timeout court pour éviter de bloquer le site
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    // En production, on évite d'afficher l'erreur brute pour la sécurité
    die("Erreur de connexion base de données. Vérifiez db.php");
}
?>