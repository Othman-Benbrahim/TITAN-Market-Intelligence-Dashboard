<?php
// api_performance.php - V65.1
header('Content-Type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
require_once 'db.php';

try {
    // On récupère les 20 derniers enregistrements de performance
    $stmt = $pdo->query("SELECT winrate, avg_pnl, created_at FROM titan_winrate_log ORDER BY id DESC LIMIT 20");
    $rows = array_reverse($stmt->fetchAll(PDO::FETCH_ASSOC));

    $labels = [];
    $winrates = [];
    $pnls = [];

    foreach ($rows as $r) {
        $labels[] = date('H:i', strtotime($r['created_at']));
        $winrates[] = (float)$r['winrate'];
        $pnls[] = (float)$r['avg_pnl'];
    }

    echo json_encode([
        'status' => 'ok',
        'labels' => $labels,
        'winrates' => $winrates,
        'pnls' => $pnls
    ]);

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'msg' => $e->getMessage()]);
}