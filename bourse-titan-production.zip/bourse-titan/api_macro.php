<?php
// api_macro.php - DÉTECTEUR DE RÉGIME RISK-ON / RISK-OFF
ini_set('display_errors', 0);
header('Content-Type: application/json');
require_once 'db.php';

function getTrend($pdo, $symbol) {
    // 1. Prix Actuel
    $stmt = $pdo->prepare("SELECT price FROM market_history WHERE symbol = ? ORDER BY created_at DESC LIMIT 1");
    $stmt->execute([$symbol]);
    $current = (float)$stmt->fetchColumn();

    // 2. Prix il y a 5 jours
    $stmt = $pdo->prepare("SELECT price FROM market_history WHERE symbol = ? AND created_at <= NOW() - INTERVAL 5 DAY ORDER BY created_at DESC LIMIT 1");
    $stmt->execute([$symbol]);
    $past = (float)$stmt->fetchColumn();

    // Fallback : Si l'historique a moins de 5 jours (car on vient d'ajouter le DXY)
    if ($past == 0) {
        $stmt = $pdo->prepare("SELECT price FROM market_history WHERE symbol = ? ORDER BY created_at ASC LIMIT 1");
        $stmt->execute([$symbol]);
        $past = (float)$stmt->fetchColumn();
    }

    if ($past == 0) return 0;
    return (($current - $past) / $past) * 100;
}

try {
    $dxy_trend = getTrend($pdo, 'DXY');
    $us10y_trend = getTrend($pdo, 'US10Y');

    // Définition des seuils de sensibilité (0.2% sur le Dollar c'est énorme)
    $dxy_threshold = 0.2; 
    $us10y_threshold = 1.0; 

    // MOTEUR LOGIQUE
    if ($dxy_trend > $dxy_threshold && $us10y_trend > $us10y_threshold) {
        $regime = 'RISK-OFF';
        $desc = 'DXY & US10Y EN HAUSSE (LIQUIDITÉ DRAINÉE)';
        $color = 'RED';
    } elseif ($dxy_trend < -$dxy_threshold && $us10y_trend < -$us10y_threshold) {
        $regime = 'RISK-ON';
        $desc = 'DXY & US10Y EN BAISSE (INJECTION DE LIQUIDITÉ)';
        $color = 'GREEN';
    } else {
        $regime = 'NEUTRAL';
        $desc = 'DIVERGENCE MACRO (RÉGIME DE TRANSITION)';
        $color = 'GOLD';
    }

    echo json_encode([
        'status' => 'ok',
        'dxy_trend' => round($dxy_trend, 2),
        'us10y_trend' => round($us10y_trend, 2),
        'regime' => $regime,
        'description' => $desc,
        'color' => $color
    ]);

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'msg' => $e->getMessage()]);
}
?>