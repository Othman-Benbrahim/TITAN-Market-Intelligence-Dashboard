<?php
// api_export.php - V78 "PRODUCTION GRADE"
// Intègre les listes ordonnées strictes et l'extraction du primary_driver.

header('Content-Type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
require_once 'db.php';

try {
    // 1. RÉCUPÉRATION DES DONNÉES DE BASE
    $stmt = $pdo->query("SELECT * FROM titan_history ORDER BY id DESC LIMIT 1");
    $titan = $stmt->fetch(PDO::FETCH_ASSOC);
    $db_stress_baseline = (float)$titan['global_stress'];

    $stmtVix = $pdo->query("SELECT price FROM market_data WHERE symbol = 'VIX'");
    $vix_price = (float)$stmtVix->fetchColumn();
    if (!$vix_price) $vix_price = 15.0; // Valeur refuge si VIX introuvable

    $stmtSpy = $pdo->query("SELECT change_percent, price FROM market_data WHERE symbol = 'SPY'");
    $spy = $stmtSpy->fetch(PDO::FETCH_ASSOC);

    // 2. CALCUL DES INTENSITÉS (Les capteurs bruts)
    $i_vix = max(0, min(100, ($vix_price - 15) * 5)); 
    
    $spy_change = abs((float)$spy['change_percent']);
    $rvol_raw = 100 + ($spy_change * 50);
    $i_vol = max(0, min(100, ($rvol_raw - 100))); 
    
    $i_breadth = ((float)$spy['change_percent'] < -1.5) ? 60 : 0;
    $i_baseline = $db_stress_baseline;

    // Tableau des intensités
    $intensities = [
        'VOLATILITY_VIX' => round($i_vix, 1),
        'VOLUME_PRESSURE' => round($i_vol, 1),
        'BREADTH_WASHOUT' => round($i_breadth, 1),
        'BASELINE_MACRO' => round($i_baseline, 1)
    ];

    // NOUVEAUTÉ : Tri décroissant et conversion en Tableau strict (Array of Arrays)
    arsort($intensities);
    $components_ranked = [];
    foreach ($intensities as $key => $value) {
        $components_ranked[] = [$key, $value];
    }
    
    // NOUVEAUTÉ : Extraction du driver principal
    $primary_driver = $components_ranked[0][0];

    // ----------------------------------------------------
    // 3. LA CASCADE D'AGRÉGATION ET D'ARBITRAGE
    // ----------------------------------------------------
    
    // ÉTAPE 1 : RAW MAX VECTOR
    $raw_max_vector = max($intensities);

    // ÉTAPE 2 : ARBITRAGE (SYMMETRIC_VIX_ARBITRATION)
    $post_arbitration_stress = $raw_max_vector;
    $arbitration = [
        'engaged' => false,
        'multiplier' => 1.0,
        'reason' => 'Concordant signals: no arbitration needed'
    ];
    
    if ($i_vol > 40 && $vix_price < 20) {
        $arbitration['engaged'] = true;
        $ratio = ($i_baseline > 0) ? ($i_baseline / $raw_max_vector) : 0.5;
        $arbitration['multiplier'] = round($ratio, 2);
        $arbitration['reason'] = 'SYMMETRIC_VIX_ARBITRATION: VIX near-neutral bounds compress flow-only stress';
        $post_arbitration_stress = $raw_max_vector * $arbitration['multiplier'];
    }

    // ÉTAPE 3 : VIX VETO (Hard Cap)
    $vix_veto_threshold = 18;
    $veto_cap = 40; 
    $post_veto_stress = $post_arbitration_stress;
    
    $veto = [
        'engaged' => false,
        'cap_level' => null,     
        'was_binding' => false,  
        'reason' => 'VIX above veto threshold'
    ];

    if ($vix_price < $vix_veto_threshold) {
        $veto['engaged'] = true;
        $veto['cap_level'] = $veto_cap;
        
        if ($post_veto_stress > $veto_cap) {
            $post_veto_stress = $veto_cap;
            $veto['was_binding'] = true;
        }
        
        $veto['reason'] = "VIX ({$vix_price}) < {$vix_veto_threshold} engages veto, capping maximum system stress to prevent false breakdowns";
    }

    // 4. VERDICT FINAL & NARRATIF
    $final_stress = round($post_veto_stress, 1);
    
    $color = 'BLUE'; $directive = 'SYSTEM_READY';
    $regime = 'RISK-ON';
    if ($final_stress > 60) { $color = 'RED'; $directive = 'RISK_OFF'; $regime = 'RISK-OFF'; }
    elseif ($final_stress > 40) { $color = 'GOLD'; $directive = 'HEDGED'; $regime = 'TRANSITION'; }
    else { $color = 'GREEN'; $directive = 'RISK_ON'; }

    $narrative = "Market is in {$regime} regime. ";
    if ($veto['engaged']) {
        $narrative .= "VIX is muted, engaging veto cap to prevent volume-driven overreaction.";
        if ($veto['was_binding']) $narrative .= " Cap actively restricted stress surge.";
    } elseif ($arbitration['engaged']) {
        $narrative .= "Volume spikes detected but VIX remains stable, triggering arbitration.";
    } else {
        $narrative .= "All quantitative metrics are aligned.";
    }

    // 5. GÉNÉRATION DU JSON "PRODUCTION GRADE"
    echo json_encode([
        'status' => 'ok',
        'flow' => [
            'regime' => $regime,
            'rvol' => round($rvol_raw, 1)
        ],
        'matrix' => [
            'vix_current' => round($vix_price, 2),
            'stress_score' => $final_stress,
            'primary_driver' => $primary_driver, // AJOUT IMMÉDIATEMENT LISIBLE
            'breadth' => 50,
            'intensities' => $intensities,
            'components_ranked' => $components_ranked, // AJOUT DU TABLEAU STRICT
            'arbitration' => $arbitration,
            'vix_veto' => $veto,
            'thresholds' => [
                'BREADTH_WASHOUT_ON' => 80,
                'VIX_ACCEL_ON' => 25,
                'VIX_VETO_THRESHOLD' => $vix_veto_threshold
            ]
        ],
        'audit_logic' => [
            'stress_aggregation' => 'MAX_THEN_ARBITRATED_THEN_CAPPED',
            'raw_stress_unfiltered' => round($raw_max_vector, 1), 
            'cascade' => [
                '1_raw_max_vector' => round($raw_max_vector, 1),
                '2_post_arbitration_stress' => round($post_arbitration_stress, 1),
                '3_post_veto_stress' => round($post_veto_stress, 1)
            ],
            'system_narrative' => $narrative
        ],
        'policy' => [
            'directive' => $directive,
            'color' => $color
        ]
    ], JSON_PRETTY_PRINT);

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'msg' => $e->getMessage()]);
}
?>