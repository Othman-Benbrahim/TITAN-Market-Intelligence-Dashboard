<?php
// api_public.php - V69.2 "CLEAN FEED + UUP FIX"
// Génère un JSON simplifié et filtré (Uniquement des actifs achetables).

header('Content-Type: application/json; charset=utf-8');
header("Access-Control-Allow-Origin: *");
require_once 'db.php';

// NOMS LISIBLES POUR LES SECTEURS
$asset_names = [
    'SPY' => 'Marché US (S&P 500)', 
    'QQQ' => 'Technologie (Nasdaq)', 
    'BTCUSDT' => 'Bitcoin',
    'GOLD' => 'Or (Valeur Refuge)', 
    'UUP'  => 'Dollar US (Cash)', // <--- AJOUTÉ : Pour rendre UUP compréhensible
    'XLK' => 'Tech & Logiciels', 
    'XLF' => 'Banques & Finance', 
    'XLV' => 'Santé & Pharma', 
    'XLY' => 'Luxe & Conso.', 
    'XLP' => 'Biens Essentiels', 
    'XLE' => 'Énergie', 
    'XLI' => 'Industrie',
    'XLB' => 'Matériaux', 
    'XLU' => 'Services Publics', 
    'XLRE'=> 'Immobilier', 
    'XLC' => 'Comm. & Médias'
];

try {
    // 1. RÉCUPÉRER LE SIGNAL TECHNIQUE
    $stmt = $pdo->query("SELECT global_stress FROM titan_history ORDER BY id DESC LIMIT 1");
    $stress = (int)$stmt->fetchColumn();
    $health = 100 - $stress;

    // 2. DÉFINIR LA STRATÉGIE
    $signal_color = "BLUE";
    $strategy = [];

    if ($stress >= 75) {
        // --- ROUGE (CRISE) ---
        $signal_color = "RED";
        $strategy = [
            'action' => "VENDRE / SÉCURISER",
            'timing' => "IMMÉDIAT",
            'description' => "Risque extrême. Le marché est en phase de liquidation.",
            'allocation_suggested' => "10% Actions / 90% Cash ou Or",
            'attitude' => "Défensive"
        ];
        $sort_order = "DESC"; 
        $filter_type = "DEFENSIVE";

    } elseif ($stress >= 45) {
        // --- ORANGE (INCERTITUDE) ---
        $signal_color = "GOLD";
        $strategy = [
            'action' => "ATTENDRE / HEDGER",
            'timing' => "COURT TERME",
            'description' => "Volatilité accrue. Ne pas injecter de nouveau capital.",
            'allocation_suggested' => "40% Actions / 60% Cash",
            'attitude' => "Prudente"
        ];
        $sort_order = "DESC";
        $filter_type = "MIXED";

    } else {
        // --- VERT (CROISSANCE) ---
        $signal_color = "GREEN";
        $strategy = [
            'action' => "INVESTIR / RENFORCER",
            'timing' => "LONG TERME",
            'description' => "Conditions idéales. Les acheteurs dominent.",
            'allocation_suggested' => "90% Actions / 10% Cash",
            'attitude' => "Offensive"
        ];
        $sort_order = "DESC"; 
        $filter_type = "GROWTH";
    }

    // 3. DÉTECTER LES OPPORTUNITÉS (FILTRÉES)
    // On récupère TOUT, on filtrera en PHP
    $stmt = $pdo->query("SELECT symbol, change_percent, price FROM market_data ORDER BY change_percent $sort_order");
    $assets = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $top_picks = [];
    
    // LISTE NOIRE : Actifs non achetables par le grand public ou indices bruts
    $blacklist = ['VIX', 'DXY', 'DX-Y.NYB']; 

    foreach($assets as $a) {
        $sym = $a['symbol'];

        // FILTRE 1 : Exclure les indices techniques (commençant par ^) et la blacklist
        if (strpos($sym, '^') === 0 || in_array($sym, $blacklist)) {
            continue; 
        }

        // FILTRE 2 : Logique de marché
        if ($filter_type == "DEFENSIVE") {
            // En crise, on ne recommande que l'OR (même s'il baisse un peu) ou ce qui est vert
            if ($sym == 'GOLD' || $a['change_percent'] > 0) {
                $top_picks[] = $a;
            }
        } else {
            // En croissance ou incertitude, on prend les meilleurs performers
            $top_picks[] = $a;
        }

        // On s'arrête à 3 opportunités
        if(count($top_picks) >= 3) break;
    }

    // Fallback : Si tout s'effondre et rien ne passe le filtre (ex: Krach total)
    if (empty($top_picks) && $filter_type == "DEFENSIVE") {
        $top_picks[] = ['symbol' => 'USD CASH', 'change_percent' => 0.00, 'price' => 1];
    }

    // Formatage pour le frontend
    $opportunities = [];
    foreach($top_picks as $p) {
        // On utilise le nom lisible s'il existe, sinon le symbole
        $clean_name = $asset_names[$p['symbol']] ?? $p['symbol'];
        
        $opportunities[] = [
            'name' => $clean_name,
            'ticker' => $p['symbol'],
            'performance_24h' => ($p['change_percent'] > 0 ? '+' : '') . number_format((float)$p['change_percent'], 2) . '%',
            'price' => number_format((float)$p['price'], 2)
        ];
    }

    // 4. SORTIE JSON
    echo json_encode([
        'meta' => [
            'timestamp' => time(),
            'engine' => 'TITAN_V69.2_PUBLIC'
        ],
        'indicator' => [
            'health_score' => $health,
            'signal_color' => $signal_color,
            'market_mood' => ($health > 50) ? "Optimiste" : "Pessimiste"
        ],
        'advisor' => $strategy,
        'opportunities' => $opportunities
    ], JSON_PRETTY_PRINT);

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'msg' => 'Advisor unavailable']);
}
?>