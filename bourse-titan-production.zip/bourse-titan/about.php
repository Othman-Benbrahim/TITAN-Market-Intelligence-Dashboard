<?php
// about.php - "TITAN MANIFESTO"
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>À Propos | TITAN Intelligence</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;500;700;800&display=swap" rel="stylesheet">
    <style>
        :root { --bg: #f8fafc; --text: #0f172a; --accent: #2563eb; --card: #ffffff; }
        body { background: var(--bg); color: var(--text); font-family: 'Plus Jakarta Sans', sans-serif; line-height: 1.6; }
        
        .nav-bar { background: white; padding: 20px 0; border-bottom: 1px solid #e2e8f0; }
        .brand { font-weight: 800; font-size: 1.5rem; letter-spacing: -0.5px; text-decoration: none; color: var(--text); }
        
        .hero-section { padding: 80px 0; text-align: center; }
        .hero-title { font-size: 3.5rem; font-weight: 800; margin-bottom: 20px; background: linear-gradient(135deg, #0f172a 0%, #3b82f6 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        .hero-sub { font-size: 1.2rem; color: #64748b; max-width: 700px; margin: 0 auto; }
        
        .feature-card { background: var(--card); padding: 40px; border-radius: 20px; border: 1px solid #e2e8f0; height: 100%; transition: transform 0.2s; }
        .feature-card:hover { transform: translateY(-5px); box-shadow: 0 10px 30px -10px rgba(0,0,0,0.1); }
        .icon { font-size: 2.5rem; margin-bottom: 20px; display: block; }
        
        .stat-number { font-size: 2.5rem; font-weight: 800; color: var(--accent); }
        .stat-label { font-size: 0.9rem; font-weight: 600; text-transform: uppercase; color: #94a3b8; letter-spacing: 1px; }

        .btn-primary { background: var(--text); border: none; padding: 12px 30px; border-radius: 50px; font-weight: 600; transition: 0.2s; }
        .btn-primary:hover { background: var(--accent); transform: scale(1.05); }
    </style>
</head>
<body>

<nav class="nav-bar">
    <div class="container d-flex justify-content-between align-items-center">
        <a href="public.php" class="brand">TITAN</a>
        <div>
            <a href="public.php" class="text-decoration-none text-muted me-4 fw-bold" style="font-size:0.9rem">DASHBOARD</a>
            <a href="doc.php" class="text-decoration-none text-muted fw-bold" style="font-size:0.9rem">DOCS</a>
        </div>
    </div>
</nav>

<section class="hero-section">
    <div class="container">
        <h1 class="hero-title">L'Intelligence Algorithmique<br>au service de votre Capital.</h1>
        <p class="hero-sub">TITAN n'est pas un conseiller financier humain. C'est un moteur quantitatif autonome conçu pour détecter les régimes de marché et protéger les actifs contre la volatilité extrême.</p>
        <div class="mt-5">
            <a href="public.php" class="btn btn-primary text-white text-decoration-none">VOIR LE SIGNAL LIVE</a>
        </div>
    </div>
</section>

<section class="container mb-5">
    <div class="row g-4">
        <div class="col-md-4">
            <div class="feature-card">
                <span class="icon">🧠</span>
                <h3>Moteur Quantitatif</h3>
                <p class="text-muted">Analyse en temps réel du S&P 500, du Bitcoin et de l'Or. Notre algorithme croise la volatilité (VIX), le momentum et la profondeur du marché pour générer des signaux clairs.</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="feature-card">
                <span class="icon">🔮</span>
                <h3>Oracle Prédictif</h3>
                <p class="text-muted">Grâce à des modèles vectoriels avancés, TITAN projette les trajectoires probables des actifs sur 6 mois, en prenant en compte le "Stress Global" du système financier.</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="feature-card">
                <span class="icon">🛡️</span>
                <h3>Gestion du Risque</h3>
                <p class="text-muted">Notre priorité n'est pas la spéculation, mais la préservation. Le système passe automatiquement en mode "Refuge" dès que les indicateurs macro-économiques se dégradent.</p>
            </div>
        </div>
    </div>
</section>

<section class="container py-5 border-top">
    <div class="row text-center">
        <div class="col-md-4">
            <div class="stat-number">24/7</div>
            <div class="stat-label">Surveillance Active</div>
        </div>
        <div class="col-md-4">
            <div class="stat-number">V7.1</div>
            <div class="stat-label">Version Moteur</div>
        </div>
        <div class="col-md-4">
            <div class="stat-number">Multi</div>
            <div class="stat-label">Actifs Traités</div>
        </div>
    </div>
</section>

<footer class="text-center py-4 text-muted small">
    <p>&copy; 2026 TITAN Intelligence. Technologie Propriétaire.<br>
    Ce site est une démonstration technologique et ne constitue pas un conseil en investissement.</p>
</footer>

</body>
</html>