<?php
// api_smartmoney.php - RADAR INSTITUTIONNEL (VIA FINNHUB)
ini_set('display_errors', 0);
header('Content-Type: application/json');

$symbol = $_GET['symbol'] ?? 'SPY';

// ⚠️ REMPLACEZ PAR VOTRE CLÉ API FINNHUB GRATUITE
$finnhub_key = "d6qpptpr01qgdhqbtb5gd6qpptpr01qgdhqbtb60"; 

try {
    // Finnhub ne lit pas les cryptos ou le VIX de la même manière pour les recommandations
    $unsupported = ['BTCUSDT', 'VIX', 'GOLD'];
    
    if (in_array($symbol, $unsupported)) {
        echo json_encode([
            'status' => 'ok',
            'supported' => false,
            'msg' => 'NON ÉLIGIBLE (Actif Décentralisé / Indice)'
        ]);
        exit;
    }

    // API 1 : Recommendation Trends (Consensus des Analystes)
    $url = "https://finnhub.io/api/v1/stock/recommendation?symbol={$symbol}&token={$finnhub_key}";
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    $response = curl_exec($ch);
    curl_close($ch);

    $data = json_decode($response, true);

    if (is_array($data) && count($data) > 0) {
        $latest = $data[0]; // Le mois le plus récent
        
        $strongBuy = (int)$latest['strongBuy'];
        $buy = (int)$latest['buy'];
        $hold = (int)$latest['hold'];
        $sell = (int)$latest['sell'];
        $strongSell = (int)$latest['strongSell'];
        
        $total_bullish = $strongBuy + $buy;
        $total_bearish = $strongSell + $sell;
        $total_analysts = $total_bullish + $total_bearish + $hold;
        
        if ($total_analysts == 0) {
            echo json_encode(['status' => 'ok', 'supported' => false, 'msg' => 'AUCUNE DONNÉE INSTITUTIONNELLE']);
            exit;
        }

        $bull_percent = round(($total_bullish / $total_analysts) * 100);
        $bear_percent = round(($total_bearish / $total_analysts) * 100);
        
        // Déduction du consensus
        if ($bull_percent > 60) $consensus = "ACHAT FORT (ACCUMULATION)";
        elseif ($bear_percent > 60) $consensus = "VENTE FORTE (DISTRIBUTION)";
        else $consensus = "NEUTRE / HOLD";

        echo json_encode([
            'status' => 'ok',
            'supported' => true,
            'consensus' => $consensus,
            'bullish_percent' => $bull_percent,
            'bearish_percent' => $bear_percent,
            'analysts_count' => $total_analysts,
            'period' => $latest['period']
        ]);
    } else {
        echo json_encode(['status' => 'ok', 'supported' => false, 'msg' => 'AUCUN CONSENSUS DÉTECTÉ']);
    }

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'msg' => 'Erreur de connexion Finnhub']);
}
?>