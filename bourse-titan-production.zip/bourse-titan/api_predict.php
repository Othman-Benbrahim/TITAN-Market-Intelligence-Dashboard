<?php
// api_predict.php - PONT VERS L'IA PYTHON (MODULE XAI)
ini_set('display_errors', 0);
header('Content-Type: application/json');

$symbol = $_GET['symbol'] ?? 'SPY';

// ⚠️ REMPLACEZ PAR L'URL EXACTE DE VOTRE APPLICATION PYTHON
// Si votre Python tourne sur un sous-domaine, mettez-le ici (ex: https://api.visiondufutur.com/predict/)
$python_url = "https://api.visiondufutur.com/predict/" . $symbol;

$ch = curl_init($python_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_TIMEOUT, 5); // Timeout court pour ne pas bloquer le site
$result = curl_exec($ch);
curl_close($ch);

if ($result) {
    echo $result;
} else {
    echo json_encode(['status' => 'error', 'msg' => 'Cortex Python injoignable']);
}
?>