<?php
// api_history.php - V18 "MULTI-MODEL XGBOOST INTEGRATION + XAI EXPLAINABILITY"
// Connecte le backend PHP à l'API Python Flask pour ancrer la prédiction Hybride de n'importe quel actif.

ini_set('display_errors', 0);
header('Content-Type: application/json');
require_once 'db.php';

$symbol = $_GET['symbol'] ?? 'SPY';

$assets_config = [
    'SPY' => ['beta' => 1.0], 'QQQ' => ['beta' => 1.2], 'BTCUSDT' => ['beta' => 1.5],
    'GOLD' => ['beta' => -0.4], 'VIX' => ['beta' => -2.0], 'UUP' => ['beta' => -0.3]
];
$conf = $assets_config[$symbol] ?? ['beta' => 1.0];

try {
    // =========================================================================
    // 🧠 1. APPEL AU MICRO-SERVICE PYTHON (XGBOOST MULTI-MODÈLES)
    // =========================================================================
    $ml_prediction = null;
    $ml_explanation = "ANALYSE EN COURS..."; // NOUVEAU : Initialisation de l'explicabilité
    
    // ⚠️ ATTENTION : REMPLACEZ CETTE URL PAR LA VRAIE ADRESSE DE VOTRE API ALWAYSDATA
    $api_url = "http://api.visiondufutur.com/predict/" . $symbol; 
    
    // Sécurité vitale : On met un timeout de 1.5 seconde. 
    // Si l'IA n'a pas encore de modèle pour cet actif, PHP ignore l'erreur et trace la courbe classique.
    $ctx = stream_context_create(['http' => ['timeout' => 1.5]]); 
    $response = @file_get_contents($api_url, false, $ctx);

    if ($response) {
        $ml_data = json_decode($response, true);
        if (isset($ml_data['status']) && $ml_data['status'] === 'ok') {
            $ml_prediction = (float)$ml_data['prediction'];
            
            // NOUVEAU : On capture l'explication renvoyée par l'API
            if (isset($ml_data['explanation'])) {
                $ml_explanation = $ml_data['explanation'];
            }
        }
    }

    // =========================================================================
    // 2. RÉCUPÉRATION DU CERVEAU IA (TITAN CORTEX)
    // =========================================================================
    $stmt_ai = $pdo->prepare("SELECT weight_oracle, weight_echo FROM titan_cortex WHERE symbol = ?");
    $stmt_ai->execute([$symbol]);
    $ai_brain = $stmt_ai->fetch(PDO::FETCH_ASSOC);

    $w_oracle = $ai_brain ? (float)$ai_brain['weight_oracle'] : 0.5;
    $w_echo   = $ai_brain ? (float)$ai_brain['weight_echo'] : 0.5;

    $stmt = $pdo->query("SELECT global_stress FROM titan_history ORDER BY id DESC LIMIT 1");
    $stress = (float)$stmt->fetchColumn();
    if (!$stress) $stress = 50;

    $stmt = $pdo->prepare("SELECT price, created_at FROM market_history WHERE symbol = ? AND created_at > NOW() - INTERVAL 180 DAY ORDER BY created_at ASC");
    $stmt->execute([$symbol]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $daily = [];
    foreach ($rows as $r) {
        $day = date('Y-m-d', strtotime($r['created_at']));
        $daily[$day] = $r; 
    }
    ksort($daily);
    $daily = array_values($daily);
    
    $total_hist = count($daily);
    $display_days = 30; 
    $future_days = 30;  

    $start_idx = max(0, $total_hist - $display_days);
    $past_records = array_slice($daily, $start_idx);
    
    $out_labels = [];
    $out_real = [];
    $out_proj = []; 
    $out_echo = []; 
    $out_ai   = []; 

    $last_price = 100;
    $last_timestamp = time();

    // REMPLISSAGE DU PASSÉ
    foreach ($past_records as $r) {
        $last_timestamp = strtotime($r['created_at']);
        $last_price = (float)$r['price'];
        
        $out_labels[] = date('d/m', $last_timestamp);
        $out_real[] = $last_price;
        $out_proj[] = null;
        $out_echo[] = null;
        $out_ai[]   = null;
    }

    // PIVOT (Soudure)
    if (count($out_real) > 0) {
        $out_proj[count($out_proj) - 1] = $last_price;
        $out_echo[count($out_echo) - 1] = $last_price;
        $out_ai[count($out_ai) - 1]     = $last_price;
    }

    // ECHO FRACTAL
    $pattern_size = 5;
    $echo_future_prices = [];

    if ($total_hist >= ($pattern_size + $future_days)) {
        $all_prices = array_column($daily, 'price');
        $current_shape = array_slice($all_prices, -$pattern_size);
        $base_curr = $current_shape[0] ?: 1;
        $norm_curr = array_map(function($p) use ($base_curr) { return $p / $base_curr; }, $current_shape);

        $best_dist = INF; $best_idx = -1;
        $limit = $total_hist - $pattern_size - $future_days;
        for ($i = 0; $i <= $limit; $i++) {
            $window = array_slice($all_prices, $i, $pattern_size);
            $base_win = $window[0];
            if ($base_win == 0) continue;
            $norm_win = array_map(function($p) use ($base_win) { return $p / $base_win; }, $window);
            $dist = 0;
            for ($j=0; $j<$pattern_size; $j++) $dist += pow($norm_curr[$j] - $norm_win[$j], 2);
            if ($dist < $best_dist) { $best_dist = $dist; $best_idx = $i; }
        }

        $pivot_hist = $all_prices[$best_idx + $pattern_size - 1];
        if ($pivot_hist > 0) {
            for ($k = 1; $k <= $future_days; $k++) {
                $ref_price = $all_prices[$best_idx + $pattern_size - 1 + $k];
                $pct_change = ($ref_price - $pivot_hist) / $pivot_hist;
                $echo_future_prices[] = $last_price * (1 + $pct_change);
            }
        }
    }
    if (empty($echo_future_prices)) { for ($k=0;$k<$future_days;$k++) $echo_future_prices[] = $last_price; }

    // ORACLE QUANTITATIF
    $inertia = 0;
    if (count($out_real) >= 5) {
        $first = $out_real[count($out_real)-5];
        if ($first != 0) {
            $inertia = (($last_price - $first) / $first) * 0.3;
            $inertia = max(-0.05, min(0.05, $inertia)); 
        }
    }
    $macro_force = (50 - $stress) / 1000; 
    $fundamental_drift = $macro_force * $conf['beta'];
    $daily_drift = ($inertia + $fundamental_drift) / 3; 
    $volatility = $stress / 8000; 
    $current_oracle_price = $last_price;

    $seed = crc32($symbol) + floor(time() / 1800);
    mt_srand($seed);

    $ml_offset = 0;

    // REMPLISSAGE DU FUTUR
    for ($k = 1; $k <= $future_days; $k++) {
        $next_time = $last_timestamp + ($k * 86400); 
        $out_labels[] = date('d/m', $next_time);
        $out_real[] = null;
        
        // 1. Calcul Oracle
        $decay = 1 / sqrt($k); 
        $noise = (mt_rand(-100, 100) / 100) * $volatility * abs($conf['beta']); 
        $move = ($daily_drift * $decay) + $noise;
        $current_oracle_price = $current_oracle_price * (1 + $move);
        $out_proj[] = $current_oracle_price;
        
        // 2. Calcul Echo
        $val_echo = $echo_future_prices[$k-1];
        $out_echo[] = $val_echo;

        // 3. Calcul HYBRIDE IA (La fusion pondérée Macro/Fractal)
        $val_hybrid = ($current_oracle_price * $w_oracle) + ($val_echo * $w_echo);

        // 4. ANCRAGE XGBOOST (Intégration du Micro-Service Python)
        if ($ml_prediction !== null) {
            if ($k == 1) {
                // Le premier jour, la courbe passe EXACTEMENT sur la prédiction de Python
                $ml_offset = $ml_prediction - $val_hybrid;
            }
            // Pour les jours suivants, la tendance XGBoost s'estompe doucement (sqrt) pour rejoindre le consensus
            $val_hybrid = $val_hybrid + ($ml_offset / sqrt($k));
        }

        $out_ai[] = $val_hybrid;
    }

    echo json_encode([
        'status' => 'ok',
        'asset' => $symbol,
        'labels' => $out_labels,
        'real_data' => $out_real,
        'proj_data' => $out_proj,
        'echo_data' => $out_echo,
        'ai_data'   => $out_ai,
        'ai_weights' => [           
            'oracle' => $w_oracle,
            'echo' => $w_echo
        ],
        'xgboost_active' => ($ml_prediction !== null), // Permet de savoir si l'API a répondu
        'ai_explanation' => $ml_explanation // NOUVEAU : On intègre l'explication dans la réponse !
    ]);

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'msg' => $e->getMessage()]);
}
?>