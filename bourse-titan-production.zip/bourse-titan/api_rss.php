<?php
// api_rss.php - V2 "OPML MULTI-THREAD ENGINE"
// Lit un annuaire OPML, télécharge les flux en parallèle et fusionne les actus.

header('Content-Type: application/json; charset=utf-8');

// L'URL de votre fichier OPML (Remplacez par la vraie URL de l'OPML Atlas Flux)
$opml_url = "https://atlasflux.saynete.net/atlas_des_flux_rss_fra_economie_investissement.opml"; // <-- À ADAPTER

try {
    // 1. TÉLÉCHARGEMENT DE L'ANNUAIRE OPML
    $ch_opml = curl_init($opml_url);
    curl_setopt($ch_opml, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch_opml, CURLOPT_TIMEOUT, 3);
    curl_setopt($ch_opml, CURLOPT_SSL_VERIFYPEER, false);
    $opml_content = curl_exec($ch_opml);
    curl_close($ch_opml);

    if (!$opml_content) throw new Exception("Impossible de lire l'OPML.");

    $opml_xml = @simplexml_load_string($opml_content);
    if (!$opml_xml) throw new Exception("Fichier OPML invalide.");

    // 2. EXTRACTION DES FLUX RSS
    $feed_urls = [];
    // Recherche de toutes les balises <outline> contenant un attribut xmlUrl
    foreach ($opml_xml->xpath('//outline[@xmlUrl]') as $outline) {
        $feed_urls[] = (string)$outline['xmlUrl'];
    }

    if (empty($feed_urls)) throw new Exception("Aucun flux RSS trouvé dans l'OPML.");

    // Sécurité : On limite à 10 flux maximum pour ne pas faire exploser le serveur
    $feed_urls = array_slice($feed_urls, 0, 10);

    // 3. TÉLÉCHARGEMENT PARALLÈLE (CURL_MULTI)
    $mh = curl_multi_init();
    $curl_array = [];

    foreach ($feed_urls as $i => $url) {
        $curl_array[$i] = curl_init($url);
        curl_setopt($curl_array[$i], CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl_array[$i], CURLOPT_TIMEOUT, 2); // 2 sec max par flux
        curl_setopt($curl_array[$i], CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($curl_array[$i], CURLOPT_SSL_VERIFYPEER, false);
        curl_multi_add_handle($mh, $curl_array[$i]);
    }

    $running = null;
    do {
        curl_multi_exec($mh, $running);
    } while ($running > 0);

    // 4. PARSAGE ET FUSION DES ARTICLES
    $all_articles = [];

    foreach ($feed_urls as $i => $url) {
        $xml_content = curl_multi_getcontent($curl_array[$i]);
        curl_multi_remove_handle($mh, $curl_array[$i]);
        
        if ($xml_content) {
            $rss = @simplexml_load_string($xml_content);
            if ($rss && isset($rss->channel->item)) {
                foreach ($rss->channel->item as $item) {
                    $pubDate = (string)$item->pubDate;
                    $timestamp = strtotime($pubDate);
                    
                    // On ne garde que les articles qui ont une date valide
                    if ($timestamp) {
                        $all_articles[] = [
                            'timestamp' => $timestamp,
                            'title' => (string)$item->title,
                            'link' => (string)$item->link,
                            'date' => date('d/m H:i', $timestamp)
                        ];
                    }
                }
            }
        }
    }
    curl_multi_close($mh);

    // 5. TRI ET FORMATAGE DU RÉSULTAT
    // On trie tous les articles du plus récent au plus ancien
    usort($all_articles, function($a, $b) {
        return $b['timestamp'] <=> $a['timestamp'];
    });

    // On ne renvoie que les 8 plus récents pour le tableau de bord
    $final_feed = array_slice($all_articles, 0, 8);

    echo json_encode([
        'status' => 'ok',
        'source' => 'OPML Aggregator',
        'feeds_scanned' => count($feed_urls),
        'articles' => $final_feed
    ]);

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'msg' => $e->getMessage()]);
}
?>