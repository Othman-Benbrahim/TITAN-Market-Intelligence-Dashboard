<?php
// fetch_data.php - V86 "OHLCV + MACRO + NLP SENTIMENT ENGINE"
// Récupère Prix, Open, High, Low, Volume, Macro et le Sentiment des News.

ini_set('display_errors', 1);
error_reporting(E_ALL);
date_default_timezone_set('Europe/Paris');
@set_time_limit(120);

require_once 'db.php';

// --- 0. ANTI-SURCHARGE (1 min) ---
$last_update_file = 'last_update.txt';
if (!isset($_GET['force'])) {
    if (file_exists($last_update_file) && (time() - (int)file_get_contents($last_update_file) < 60)) {
        die("⏳ En veille (Protection Anti-Flood 60s).");
    }
}
file_put_contents($last_update_file, time());

// NETTOYAGE DB (Garde 6 mois)
$pdo->query("DELETE FROM market_history WHERE created_at < NOW() - INTERVAL 180 DAY");

$real_data = [];
$sources_ok = 0;

// --- 1. RÉCUPÉRATION DU BITCOIN (VIA BINANCE) ---
$ch_btc = curl_init('https://api.binance.com/api/v3/ticker/24hr?symbol=BTCUSDT');
curl_setopt($ch_btc, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch_btc, CURLOPT_TIMEOUT, 3);
curl_setopt($ch_btc, CURLOPT_USERAGENT, 'TITAN_ENGINE/1.0');
$btc_res = curl_exec($ch_btc);
curl_close($ch_btc);

if ($btc_res) {
    $b_data = json_decode($btc_res, true);
    if (isset($b_data['lastPrice'])) {
        $real_data['BTCUSDT'] = [
            'price' => (float)$b_data['lastPrice'],
            'change' => (float)$b_data['priceChangePercent'],
            'open' => (float)$b_data['openPrice'],
            'high' => (float)$b_data['highPrice'],
            'low' => (float)$b_data['lowPrice'],
            'volume' => (float)$b_data['volume']
        ];
        $sources_ok++;
    }
}

// --- 2. RÉCUPÉRATION TRADFI (VIA YAHOO V8) ---
$tradfi_assets = [
    'SPY' => 'SPY', 'QQQ' => 'QQQ', 'VIX' => '^VIX', 'GOLD' => 'GC=F',
    'DXY' => 'DX-Y.NYB', 'US10Y' => '^TNX', 
    'XLK' => 'XLK', 'XLF' => 'XLF', 'XLV' => 'XLV', 'XLY' => 'XLY', 
    'XLP' => 'XLP', 'XLE' => 'XLE', 'XLI' => 'XLI', 'XLB' => 'XLB', 
    'XLU' => 'XLU', 'XLRE'=> 'XLRE', 'XLC' => 'XLC'
];

$mh = curl_multi_init();
$curl_array = [];

foreach ($tradfi_assets as $titan_sym => $yahoo_sym) {
    $url = 'https://query2.finance.yahoo.com/v8/finance/chart/' . urlencode($yahoo_sym) . '?interval=1d&range=2d';
    $curl_array[$titan_sym] = curl_init($url);
    curl_setopt($curl_array[$titan_sym], CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl_array[$titan_sym], CURLOPT_TIMEOUT, 4);
    curl_setopt($curl_array[$titan_sym], CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl_array[$titan_sym], CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)');
    curl_multi_add_handle($mh, $curl_array[$titan_sym]);
}

$running = null;
do { curl_multi_exec($mh, $running); } while ($running > 0);

foreach ($tradfi_assets as $titan_sym => $yahoo_sym) {
    $response = curl_multi_getcontent($curl_array[$titan_sym]);
    curl_multi_remove_handle($mh, $curl_array[$titan_sym]);
    
    if ($response) {
        $y_data = json_decode($response, true);
        if (isset($y_data['chart']['result'][0]['meta']['regularMarketPrice'])) {
            $meta = $y_data['chart']['result'][0]['meta'];
            $price = (float)$meta['regularMarketPrice'];
            
            $prev_close = $price; 
            if (isset($meta['previousClose'])) {
                $prev_close = (float)$meta['previousClose'];
            } elseif (isset($meta['chartPreviousClose'])) {
                $prev_close = (float)$meta['chartPreviousClose'];
            }
            
            $change_pct = ($prev_close > 0) ? (($price - $prev_close) / $prev_close) * 100 : 0;
            
            $real_data[$titan_sym] = [
                'price' => $price,
                'change' => $change_pct,
                'open' => (float)($meta['regularMarketOpen'] ?? $price),
                'high' => (float)($meta['regularMarketDayHigh'] ?? $price),
                'low' => (float)($meta['regularMarketDayLow'] ?? $price),
                'volume' => (float)($meta['regularMarketVolume'] ?? 0)
            ];
            $sources_ok++;
        }
    }
}
curl_multi_close($mh);

// =====================================================================
// 🧠 3. NOUVEAU : RÉCUPÉRATION DU SENTIMENT (NLP NEWS API)
// =====================================================================
$sentiment_score = 0; // 0 = Neutre, 1 = Bullish/Dovish, -1 = Bearish/Hawkish
try {
    $ch_news = curl_init('https://www.jblanked.com/news/api/list/');
    curl_setopt($ch_news, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch_news, CURLOPT_TIMEOUT, 3);
    curl_setopt($ch_news, CURLOPT_SSL_VERIFYPEER, false);
    $news_res = curl_exec($ch_news);
    curl_close($ch_news);

    if ($news_res) {
        $news_data = json_decode($news_res, true);
        if (is_array($news_data) && count($news_data) > 0) {
            $bull_points = 0;
            $bear_points = 0;
            
            // On analyse les 5 dernières actus économiques
            $recent_news = array_slice($news_data, 0, 5);
            foreach ($recent_news as $item) {
                // On met tout en minuscules pour faciliter la recherche
                $text = strtolower(json_encode($item));
                
                if (strpos($text, 'bullish') !== false || strpos($text, 'dovish') !== false) $bull_points++;
                if (strpos($text, 'bearish') !== false || strpos($text, 'hawkish') !== false) $bear_points++;
            }
            
            if ($bull_points > $bear_points) $sentiment_score = 1;
            elseif ($bear_points > $bull_points) $sentiment_score = -1;
        }
    }
} catch (Exception $e) {
    // Si l'API News plante, on reste neutre pour ne pas bloquer le système
    $sentiment_score = 0; 
}
// =====================================================================

// --- 4. TRAITEMENT ET ENREGISTREMENT ---
$vix_level = 15;
$spy_price = 0;
$all_symbols = array_merge(['BTCUSDT'], array_keys($tradfi_assets));

foreach ($all_symbols as $sym) {
    if (isset($real_data[$sym])) {
        $new_price = $real_data[$sym]['price'];
        $change = $real_data[$sym]['change'];
        $open = $real_data[$sym]['open'];
        $high = $real_data[$sym]['high'];
        $low = $real_data[$sym]['low'];
        $volume = $real_data[$sym]['volume'];
    } else {
        $stmt = $pdo->prepare("SELECT price FROM market_data WHERE symbol = ?");
        $stmt->execute([$sym]);
        $new_price = $stmt->fetchColumn() ?: 150.00;
        $change = 0; $open = $new_price; $high = $new_price; $low = $new_price; $volume = 0;
    }

    if ($sym == 'SPY') $spy_price = $new_price;
    if ($sym == 'VIX') $vix_level = $new_price;

    // Mise à jour de market_data (données temps réel)
    $stmt = $pdo->prepare("INSERT INTO market_data (symbol, price, change_percent, updated_at) VALUES (?, ?, ?, NOW()) ON DUPLICATE KEY UPDATE price = ?, change_percent = ?, updated_at = NOW()");
    $stmt->execute([$sym, $new_price, $change, $new_price, $change]);
    
    // 🌟 INJECTION DU SENTIMENT DANS L'HISTORIQUE
    $stmt_hist = $pdo->prepare("INSERT INTO market_history (symbol, price, open, high, low, volume, sentiment_score, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
    $stmt_hist->execute([$sym, $new_price, $open, $high, $low, $volume, $sentiment_score]);
    
    // Le Bulletin de Notes de l'IA (Correction)
    $pdo->prepare("UPDATE ai_predictions SET actual_price = ? WHERE symbol = ? AND target_date = CURDATE()")->execute([$new_price, $sym]);
}

// --- 5. CALCUL DU STRESS (ALGORITHME TITAN) ---
$stmt = $pdo->query("SELECT change_percent FROM market_data WHERE symbol != 'VIX'");
$markets = $stmt->fetchAll(PDO::FETCH_COLUMN);
$declining = 0; $total = count($markets);

foreach($markets as $c) { if ($c <= 0) $declining++; }
$breadth_bear = ($total > 0) ? ($declining / $total) * 100 : 50;

$s_breadth = 100 / (1 + exp(-0.12 * ($breadth_bear - 60)));
$s_vix = 100 / (1 + exp(-0.3 * ($vix_level - 20)));
$stress = max((int)$s_breadth, (int)$s_vix);

if ($vix_level < 18 && $stress > 60) $stress = 55;

$pdo->prepare("INSERT INTO titan_history (timestamp_utc, global_stress, created_at) VALUES (?, ?, NOW())")->execute([time(), $stress]);

// --- 6. AFFICHAGE DES RÉSULTATS ---
echo "<h3>✅ TITAN HYBRID ENGINE EXECUTED (OHLCV + SENTIMENT READY)</h3>";
echo "<b>Bilan des collectes :</b> $sources_ok / " . count($all_symbols) . " actifs récupérés.<br>";

// Affichage du sentiment détecté pour vérification
$sent_text = "NEUTRE ⚪";
if ($sentiment_score == 1) $sent_text = "HAUSSIER / DOVISH 🟢";
if ($sentiment_score == -1) $sent_text = "BAISSIER / HAWKISH 🔴";
echo "<br>📰 <b>Sentiment Global NLP :</b> " . $sent_text . "<br><br>";

if (isset($real_data['BTCUSDT'])) echo "🟠 <b>BITCOIN :</b> " . number_format($real_data['BTCUSDT']['price'], 2, '.', ' ') . " $ <br>";
if (isset($real_data['SPY'])) echo "🔵 <b>S&P 500 :</b> " . number_format($real_data['SPY']['price'], 2, '.', ' ') . " $ <br>";

echo "<br>🌐 <b>Stress Système Actuel :</b> $stress%";
?>