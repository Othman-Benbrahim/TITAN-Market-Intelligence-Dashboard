<?php
// public.php - V74 "TITAN INVESTOR ASSET-SPECIFIC" (Fix: Metrics update per asset)
require_once 'db.php';

// Stats globales SEO
$stats = $pdo->query("SELECT COUNT(*) as total, SUM(CASE WHEN pnl_percent > 0 THEN 1 ELSE 0 END) as wins FROM titan_performance WHERE status = 'CLOSED'")->fetch();
$total_trades = $stats['total'] ?: 1;
$win_rate = round(($stats['wins'] / $total_trades) * 100, 1);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TITAN | Advisor & Intelligence</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;700;800&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root { --bg: #f8fafc; --card: #ffffff; --primary: #0f172a; --accent: #3b82f6; --success: #10b981; --danger: #ef4444; --warning: #f59e0b; }
        body { background: var(--bg); color: var(--primary); font-family: 'Plus Jakarta Sans', sans-serif; padding-bottom: 80px; }
        
        .nav-bar { background: white; padding: 15px 0; border-bottom: 1px solid #e2e8f0; margin-bottom: 30px; }
        .brand { font-weight: 800; font-size: 1.4rem; letter-spacing: -0.5px; }
        
        .api-btn { font-size: 0.75rem; font-weight: 600; background: white; color: var(--accent); border: 1px solid var(--accent); padding: 6px 18px; border-radius: 50px; cursor: pointer; transition: 0.2s; }
        .api-btn:hover { background: var(--accent); color: white; }
        .api-btn.copied { background: var(--success); border-color: var(--success); color: white; }
        
        .terminal-btn { font-size: 0.75rem; font-weight: 700; color: #64748b; text-decoration: none; border: 1px solid #cbd5e1; padding: 6px 15px; border-radius: 50px; margin-right: 10px; transition: 0.2s; }
        .terminal-btn:hover { background: #0f172a; color: white; border-color: #0f172a; }

        .metric-card { background: white; padding: 25px; border-radius: 16px; border: 1px solid #e2e8f0; height: 100%; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .signal-card { background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); color: white; padding: 30px; border-radius: 20px; }
        
        .weather-icon { font-size: 4rem; line-height: 1; margin-bottom: 10px; }
        .action-title { font-size: 2rem; font-weight: 800; line-height: 1.1; margin-bottom: 10px; }
        
        .alloc-badge { background: rgba(255,255,255,0.15); padding: 5px 12px; border-radius: 8px; font-size: 0.8rem; font-weight: 600; display: inline-block; margin-top: 10px; }
        
        .opp-item { display: flex; justify-content: space-between; align-items: center; padding: 15px 0; border-bottom: 1px solid #f1f5f9; }
        .opp-item:last-child { border: none; }
        .opp-name { font-weight: 700; color: var(--primary); display: block; font-size: 0.95rem; }
        .opp-sub { font-size: 0.8rem; color: #64748b; }
        .opp-val { font-weight: 700; font-size: 1rem; }
        
        .section-title { font-size: 0.8rem; font-weight: 700; text-transform: uppercase; color: #94a3b8; letter-spacing: 1px; margin-bottom: 15px; }

        /* Badges d'action */
        .badge-action { padding: 6px 12px; border-radius: 8px; font-size: 0.75rem; font-weight: 800; text-transform: uppercase; margin-right: 12px; display: inline-block; min-width: 90px; text-align: center; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
        .bg-buy { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
        .bg-sell { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
        .bg-hold { background: #fef3c7; color: #92400e; border: 1px solid #fde68a; }

        /* Chart Specifics */
        .chart-container { position: relative; height: 220px; width: 100%; }
        
        /* ONGLETS GRAPHIQUE */
        .chart-tabs { display: flex; gap: 10px; margin-bottom: 15px; }
        .tab-btn { background: #f1f5f9; border: none; padding: 5px 15px; border-radius: 20px; font-size: 0.75rem; font-weight: 700; color: #64748b; cursor: pointer; transition: 0.2s; }
        .tab-btn.active { background: var(--primary); color: white; }
        .tab-btn:hover { background: #e2e8f0; }

        /* Tech Bar */
        .tech-bar { display: flex; gap: 15px; margin-top: 20px; }
        .tech-item { flex: 1; background: #f8fafc; padding: 12px; border-radius: 12px; text-align: center; border: 1px solid #e2e8f0; }
        .tech-label { font-size: 0.65rem; color: #64748b; font-weight: 800; text-transform: uppercase; margin-bottom: 4px; letter-spacing: 0.5px; }
        .tech-val { font-size: 1.1rem; font-weight: 800; color: #0f172a; line-height: 1.2; }
        .tech-desc { font-size: 0.7rem; font-weight: 600; margin-top: 2px; }
    </style>
</head>
<body>

<div class="nav-bar">
    <div class="container d-flex justify-content-between align-items-center">
        <div class="brand">TITAN <span style="color:var(--accent)">ADVISOR</span></div>
        <div class="d-flex align-items-center">
            <a href="about.php" class="text-decoration-none text-muted fw-bold me-3" style="font-size:0.75rem;">ℹ️ À PROPOS</a>
            
            <a href="index.php" class="terminal-btn">⚡ TERMINAL</a>
            <span class="d-none d-md-block text-muted small fst-italic me-3">IA d'Investissement</span>
            <button onclick="copyPublicJSON()" id="btn-json" class="api-btn">📡 COPIER LE SIGNAL</button>
        </div>
    </div>
</div>

<div class="container">

    <div class="row g-4 mb-5">
        
        <div class="col-lg-6">
            <div class="signal-card h-100">
                <div class="d-flex justify-content-between h-100 flex-column">
                    <div>
                        <div class="section-title text-white-50">STRATÉGIE DU JOUR</div>
                        <h2 class="action-title" id="advisor-action">Analyse...</h2>
                        <p class="text-white-50 mb-3" id="advisor-desc">Chargement des flux...</p>
                        <div class="d-flex gap-2 flex-wrap">
                            <span class="alloc-badge">⏱️ <span id="advisor-timing">--</span></span>
                            <span class="alloc-badge">💰 <span id="advisor-alloc">--</span></span>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between align-items-end mt-4">
                        <div>
                            <div class="fs-6 text-white-50">Santé Marché</div>
                            <div class="fw-bold fs-2" id="advisor-health">--%</div>
                        </div>
                        <div class="weather-icon" id="advisor-icon">⏳</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="metric-card">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="section-title mb-0">ORACLE VISION (<span id="chart-title-asset">SPY</span>)</span>
                    <div>
                        <button onclick="copyAssetJSON()" id="btn-asset-json" class="badge bg-primary border-0 me-2" style="cursor:pointer; text-decoration:none;">📄 JSON ACTIF</button>
                        <span class="badge bg-primary bg-opacity-10 text-primary">1 MOIS</span>
                    </div>
                </div>
                
                <div class="chart-tabs">
                    <button class="tab-btn active" onclick="switchAsset('SPY', this)">MARCHÉ</button>
                    <button class="tab-btn" onclick="switchAsset('BTCUSDT', this)">BITCOIN</button>
                    <button class="tab-btn" onclick="switchAsset('GOLD', this)">OR</button>
                </div>

                <div class="chart-container">
                    <canvas id="publicChart"></canvas>
                </div>
                
                <div class="tech-bar">
                    <div class="tech-item">
                        <div class="tech-label">NIVEAU DE RISQUE</div>
                        <div class="tech-val" id="tech-vix">--</div>
                        <div class="tech-desc" id="desc-vix">...</div>
                    </div>
                    <div class="tech-item">
                        <div class="tech-label">PRESSION ACHETEUR</div>
                        <div class="tech-val" id="tech-rvol">--%</div>
                        <div class="tech-desc" id="desc-rvol">...</div>
                    </div>
                    <div class="tech-item">
                        <div class="tech-label">SANTÉ GLOBALE</div>
                        <div class="tech-val" id="tech-breadth">--%</div>
                        <div class="tech-desc" id="desc-breadth">...</div>
                    </div>
                </div>

                <div style="margin-top: 20px; padding: 12px 15px; background: #fffbeb; border-left: 3px solid #f59e0b; border-radius: 6px;">
                    <p style="margin: 0; font-size: 0.65rem; color: #92400e; font-weight: 600; line-height: 1.4;">
                        ⚠️ AVERTISSEMENT : Les courbes de prédiction (Oracle Quantitatif et Echo Fractal) sont des simulations mathématiques théoriques basées sur la volatilité, l'inertie et les correspondances de motifs historiques à l'instant T. Elles illustrent des scénarios de probabilité et ne constituent en aucun cas des conseils en investissement ou des garanties de prix futurs.
                    </p>
                </div>

            </div>
        </div>

    </div>

    <div class="row g-4 mb-5">
        
        <div class="col-lg-4">
            <div class="metric-card">
                <div class="section-title">TOP CIBLES (24H)</div>
                <div id="opportunities-list">
                    <p class="text-muted small">Recherche...</p>
                </div>
                <div class="mt-3 text-center">
                    <small class="text-muted fst-italic" style="font-size:0.7rem">*Basé sur le momentum actuel</small>
                </div>
            </div>
        </div>

        <div class="col-lg-8">
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="metric-card text-center">
                        <span class="section-title d-block">PERFORMANCE IA</span>
                        <div class="fs-1 fw-bold text-success" id="public-winrate"><?= $win_rate ?>%</div>
                        <p class="text-muted small mb-0">Taux de réussite</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="metric-card text-center">
                        <span class="section-title d-block">PSYCHOLOGIE</span>
                        <div class="fs-1 fw-bold text-primary" id="public-regime">...</div>
                        <p class="text-muted small mb-0">Sentiment Global</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="metric-card text-center">
                        <span class="section-title d-block">ÉTAT SYSTÈME</span>
                        <div class="fw-bold text-dark" id="system-status" style="font-size: 1.5rem;">ACTIF</div>
                        <p class="text-muted small mb-0 d-flex justify-content-center align-items-center gap-2">
                            <span style="width:8px; height:8px; background:#10b981; border-radius:50%; display:inline-block;"></span> 
                            Surveillance Live
                        </p>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <footer class="text-center text-muted small mt-5">
        <p>&copy; 2026 TITAN Intelligence. L'investissement comporte des risques.<br>
        Les performances passées ne préjugent pas des résultats futurs.</p>
    </footer>

</div>

<script>
    let publicChart = null;
    let currentAsset = 'SPY'; // Actif par défaut

    // FONCTION PRINCIPALE : CHANGER D'ACTIF
    async function switchAsset(symbol, btnElement) {
        currentAsset = symbol;
        
        // Gestion visuelle des boutons
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        btnElement.classList.add('active');
        
        // Changement du titre
        const nameMap = {'SPY': 'MARCHÉ', 'BTCUSDT': 'BITCOIN', 'GOLD': 'OR'};
        document.getElementById('chart-title-asset').innerText = nameMap[symbol] || symbol;
        
        // RECHARGEMENT DES DONNÉES
        await updateChartData();   // Graphique
        await updateAssetMetrics(); // <-- NOUVEAU : Met à jour les 3 cases techniques pour CET actif
    }

    // NOUVEAU : MET À JOUR LES MÉTRIQUES TECHNIQUES PAR ACTIF
    async function updateAssetMetrics() {
        try {
            // On appelle api_asset.php pour l'actif courant (ex: BTCUSDT)
            const res = await fetch(`api_asset.php?symbol=${currentAsset}`);
            const data = await res.json();

            if (data.gem_matrix) {
                const gem = data.gem_matrix;

                // 1. NIVEAU DE RISQUE (STR_Tension)
                // Tension de 0 à 5
                const tension = parseFloat(gem.STR_Tension);
                let riskText, riskColor, riskDesc;
                
                if (tension >= 4) { riskText = "ÉLEVÉ"; riskColor = "#ef4444"; riskDesc = "Zone de Stress"; }
                else if (tension >= 2.5) { riskText = "MODÉRÉ"; riskColor = "#f59e0b"; riskDesc = "Volatilité Active"; }
                else { riskText = "FAIBLE"; riskColor = "#10b981"; riskDesc = "Marché Calme"; }

                document.getElementById('tech-vix').innerText = riskText;
                document.getElementById('tech-vix').style.color = riskColor;
                document.getElementById('desc-vix').innerText = riskDesc;
                document.getElementById('desc-vix').style.color = riskColor;

                // 2. PRESSION ACHETEUR (SVF_Vectoriel_Flux)
                // Flux de -15 à +15. On mappe ça en pourcentage 0-100% pour l'affichage visuel
                const flux = parseFloat(gem.SVF_Vectoriel_Flux);
                // Formule approximative : (Flux + 10) * 5 pour avoir un % autour de 50%
                let fluxPct = Math.round((flux + 10) * 5); 
                fluxPct = Math.max(0, Math.min(100, fluxPct)); // Borné entre 0 et 100

                let fluxColor, fluxDesc;
                if (flux > 2) { fluxColor = "#10b981"; fluxDesc = "Flux Entrants"; }
                else if (flux < -2) { fluxColor = "#ef4444"; fluxDesc = "Flux Sortants"; }
                else { fluxColor = "#64748b"; fluxDesc = "Flux Neutres"; }

                document.getElementById('tech-rvol').innerText = fluxPct + "%";
                document.getElementById('tech-rvol').style.color = fluxColor;
                document.getElementById('desc-rvol').innerText = fluxDesc;

                // 3. SANTÉ GLOBALE (SR_Robustesse)
                // Score de 0 à 5
                const robust = parseFloat(gem.SR_Robustesse);
                const healthPct = Math.round(robust * 20); // 5 * 20 = 100%

                let healthColor, healthDesc;
                if (healthPct > 70) { healthColor = "#10b981"; healthDesc = "Structure Saine"; }
                else if (healthPct < 40) { healthColor = "#ef4444"; healthDesc = "Structure Fragile"; }
                else { healthColor = "#f59e0b"; healthDesc = "Structure Mixte"; }

                document.getElementById('tech-breadth').innerText = healthPct + "%";
                document.getElementById('tech-breadth').style.color = healthColor;
                document.getElementById('desc-breadth').innerText = healthDesc;
                document.getElementById('desc-breadth').style.color = healthColor;
            }
        } catch (e) {
            console.error("Metric Error", e);
        }
    }

    // INITIALISATION DU GRAPHIQUE
    function initChart() {
        const ctx = document.getElementById('publicChart').getContext('2d');
        Chart.defaults.font.family = 'Plus Jakarta Sans';
        Chart.defaults.color = '#64748b';
        
        publicChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [
                    {
                        label: 'Réalité ($)', 
                        data: [],
                        borderColor: '#2563eb', 
                        borderWidth: 2,
                        tension: 0.3,
                        pointRadius: 0,
                        backgroundColor: 'rgba(37, 99, 235, 0.05)',
                        fill: true
                    },
                    {
                        label: 'Oracle (Macro)',
                        data: [],
                        borderColor: '#f59e0b', 
                        borderWidth: 2,
                        borderDash: [5, 5],
                        tension: 0.3,
                        pointRadius: 0
                    },
                    { 
                        label: 'Echo (Fractal)', 
                        data: [], 
                        borderColor: '#bd00ff', 
                        borderWidth: 2, 
                        borderDash: [2, 4], 
                        tension: 0.3, 
                        pointRadius: 0 
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                        align: 'end',
                        labels: { usePointStyle: true, boxWidth: 8, font: { weight: '700', size: 10 } }
                    },
                    tooltip: { mode: 'index', intersect: false }
                },
                scales: {
                    x: { display: false },
                    y: {
                        position: 'right',
                        grid: { color: '#f1f5f9' },
                        ticks: { font: { size: 10, weight: 'bold' }, callback: function(val) { return '$' + val; } }
                    }
                },
                animation: false
            }
        });
    }

    async function updateChartData() {
        try {
            const res = await fetch(`api_history.php?symbol=${currentAsset}&range=1M`);
            const data = await res.json();
            
            if (data.status === 'ok') {
                publicChart.data.labels = data.labels;
                publicChart.data.datasets[0].data = data.real_data;
                publicChart.data.datasets[1].data = data.proj_data;
                if(data.echo_data) {
                    publicChart.data.datasets[2].data = data.echo_data;
                }
                publicChart.update();
            }
        } catch (e) { console.error("Chart Error", e); }
    }

    // COPIE JSON GÉNÉRAL
    async function copyPublicJSON() {
        const btn = document.getElementById('btn-json');
        try {
            const res = await fetch('api_public.php');
            const data = await res.json();
            const text = JSON.stringify(data, null, 4);
            if (navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(text);
            else { const ta = document.createElement("textarea"); ta.value=text; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); document.body.removeChild(ta); }
            const originalText = btn.innerText; btn.innerText = "✅ COPIÉ !"; btn.classList.add('copied');
            setTimeout(() => { btn.innerText = originalText; btn.classList.remove('copied'); }, 2000);
        } catch (err) {}
    }

    // COPIE JSON ACTIF SPÉCIFIQUE
    async function copyAssetJSON() {
        const btn = document.getElementById('btn-asset-json');
        try {
            const res = await fetch(`api_asset.php?symbol=${currentAsset}`);
            const data = await res.json();
            const text = JSON.stringify(data, null, 4);
            
            if (navigator.clipboard && window.isSecureContext) {
                await navigator.clipboard.writeText(text);
            } else {
                const ta = document.createElement("textarea");
                ta.value = text; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); document.body.removeChild(ta);
            }
            
            const originalText = btn.innerText;
            btn.innerText = "✅ COPIÉ !";
            btn.classList.remove('bg-primary');
            btn.classList.add('bg-success');
            
            setTimeout(() => {
                btn.innerText = originalText;
                btn.classList.remove('bg-success');
                btn.classList.add('bg-primary');
            }, 2000);
            
        } catch (err) { alert("Erreur rapport actif."); }
    }

    async function updateDashboard() {
        try {
            // 1. DATA STRATÉGIQUE (JSON)
            const res = await fetch('api_public.php');
            const data = await res.json();
            
            if (data.advisor) {
                const adv = data.advisor;
                const ind = data.indicator;
                
                document.getElementById('advisor-action').innerText = adv.action;
                document.getElementById('advisor-desc').innerText = adv.description;
                document.getElementById('advisor-timing').innerText = adv.timing;
                document.getElementById('advisor-alloc').innerText = adv.allocation_suggested;
                document.getElementById('advisor-health').innerText = ind.health_score + "%";
                document.getElementById('public-regime').innerText = ind.market_mood;
                
                // Couleurs et Badges Dynamiques
                const card = document.querySelector('.signal-card');
                let actionBadge = "";
                
                if (ind.signal_color === 'GREEN') {
                    card.style.background = "linear-gradient(135deg, #059669 0%, #10b981 100%)";
                    document.getElementById('advisor-icon').innerText = "☀️";
                    actionBadge = `<span class="badge-action bg-buy">🚀 ACHAT</span>`;
                } else if (ind.signal_color === 'GOLD') {
                    card.style.background = "linear-gradient(135deg, #d97706 0%, #f59e0b 100%)";
                    document.getElementById('advisor-icon').innerText = "⛅";
                    actionBadge = `<span class="badge-action bg-hold">✋ ATTENTE</span>`; 
                } else {
                    card.style.background = "linear-gradient(135deg, #b91c1c 0%, #ef4444 100%)";
                    document.getElementById('advisor-icon').innerText = "⛈️";
                    actionBadge = `<span class="badge-action bg-sell">🛡️ VENDRE</span>`;
                }

                // Liste Opportunités
                const list = document.getElementById('opportunities-list');
                list.innerHTML = "";
                data.opportunities.forEach(opp => {
                    const colorClass = opp.performance_24h.includes('-') ? 'text-danger' : 'text-success';
                    let itemBadge = actionBadge;
                    if (ind.signal_color === 'GREEN' && opp.performance_24h.includes('-')) {
                        itemBadge = `<span class="badge-action bg-hold">ATTENDRE</span>`;
                    }
                    
                    list.innerHTML += `
                        <div class="opp-item">
                            <div class="d-flex align-items-center">
                                ${itemBadge}
                                <div>
                                    <span class="opp-name">${opp.name}</span>
                                    <span class="opp-sub">${opp.ticker}</span>
                                </div>
                            </div>
                            <div class="text-end">
                                <div class="opp-val ${colorClass}">${opp.performance_24h}</div>
                                <small class="text-muted">${opp.price}</small>
                            </div>
                        </div>`;
                });
                
                document.getElementById('system-status').innerText = "OPÉRATIONNEL";
                document.getElementById('system-status').style.color = "#10b981";
            }

            // NOTE IMPORTANTE :
            // Nous avons SUPPRIMÉ la partie qui écrasait les données techniques (Tech Bar) ici.
            // Désormais, c'est la fonction updateAssetMetrics() qui s'en occupe lors du clic sur l'actif.

            // 4. WINRATE
            const perfRes = await fetch('api_performance.php');
            const perfData = await perfRes.json();
            if(perfData.winrates && perfData.winrates.length > 0) {
                const lastWR = perfData.winrates[perfData.winrates.length - 1];
                document.getElementById('public-winrate').innerText = lastWR.toFixed(1) + "%";
            }

        } catch (e) { console.error("Sync Error", e); }
    }

    document.addEventListener("DOMContentLoaded", function() {
        initChart();
        updateDashboard();      // Charge la stratégie globale
        updateAssetMetrics();   // Charge les métriques initiales du SPY
        setInterval(updateDashboard, 15000); // Rafraîchit la stratégie globale
    });
</script>

</body>
</html>